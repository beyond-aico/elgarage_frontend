import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../core/constants/app_colors.dart';
import '../core/app_ui/textured_background.dart';

// --- 1. صفحة تفاصيل التوصيل (Checkout) ---
class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  String deliveryMethod = 'CENTER'; // CENTER or HOME
  String? selectedCenter;
  final TextEditingController addressController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: TexturedBackground(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(context),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    _sectionTitle("DELIVERY METHOD"),
                    _buildMethodToggle(),
                    const SizedBox(height: 30),
                    
                    if (deliveryMethod == 'CENTER') _buildCenterSelection(provider),
                    if (deliveryMethod == 'HOME') _buildHomeForm(),
                    
                    const SizedBox(height: 50),
                    _buildConfirmButton(provider),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMethodToggle() {
    return Row(
      children: [
        _methodCard("AT CENTER", Icons.store, deliveryMethod == 'CENTER', () => setState(() => deliveryMethod = 'CENTER')),
        const SizedBox(width: 15),
        _methodCard("HOME", Icons.home, deliveryMethod == 'HOME', () => setState(() => deliveryMethod = 'HOME')),
      ],
    );
  }

  Widget _buildCenterSelection(AppProvider provider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle("SELECT SERVICE CENTER"),
        ...provider.serviceCenters.map((center) => RadioListTile(
          title: Text(center['name'], style: const TextStyle(color: AppColors.textMain, fontWeight: FontWeight.bold)),
          subtitle: Text(center['location'], style: const TextStyle(color: Colors.grey, fontSize: 12)),
          value: center['name'],
          groupValue: selectedCenter,
          activeColor: AppColors.primary,
          onChanged: (val) => setState(() => selectedCenter = val as String),
        )),
      ],
    );
  }

  Widget _buildHomeForm() {
    return Column(
      children: [
        _buildTextField(addressController, "Detailed Address & Landmark", Icons.location_on),
        const SizedBox(height: 15),
        _buildTextField(phoneController, "Phone Number", Icons.phone, isPhone: true),
      ],
    );
  }

  Widget _buildConfirmButton(AppProvider provider) {
    return SizedBox(
      width: double.infinity,
      height: 55,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.textMain, 
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))
        ),
        onPressed: () {
          if (deliveryMethod == 'CENTER' && selectedCenter == null) return;
          
          Map<String, dynamic> details = {
            'method': deliveryMethod,
            'address': deliveryMethod == 'CENTER' ? selectedCenter : addressController.text,
            'phone': phoneController.text,
          };

          // تنفيذ الطلب
          provider.placeOrder(details);

          // ✅ العودة للهوم مباشرة بعد النجاح لتنظيف الـ Stack
          showCupertinoDialog(
            context: context,
            builder: (context) => CupertinoAlertDialog(
              title: const Text("ORDER PLACED!"),
              content: const Text("Your request has been successfully recorded."),
              actions: [
                CupertinoDialogAction(
                  child: const Text("OK"),
                  onPressed: () {
                    Navigator.pop(context); // إغلاق الديالوج
                    // العودة لأول شاشة (Dashboard) ومسح الكارت والتشيك أوت
                    Navigator.of(context).popUntil((route) => route.isFirst);
                  },
                ),
              ],
            ),
          );
        },
        child: const Text("CONFIRM FINAL ORDER", style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w900)),
      ),
    );
  }

  Widget _methodCard(String label, IconData icon, bool isSelected, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: isSelected ? AppColors.primary : Colors.white,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: isSelected ? AppColors.primary : Colors.black12),
          ),
          child: Column(
            children: [
              Icon(icon, color: isSelected ? Colors.black : Colors.grey),
              const SizedBox(height: 8),
              Text(label, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 10, color: isSelected ? Colors.black : Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, IconData icon, {bool isPhone = false}) {
    return TextField(
      controller: controller,
      keyboardType: isPhone ? TextInputType.phone : TextInputType.text,
      style: const TextStyle(color: AppColors.textMain, fontWeight: FontWeight.bold),
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: AppColors.textMain),
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
      ),
    );
  }

  Widget _sectionTitle(String title) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 15),
    child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12, color: AppColors.textMain)),
  );

  Widget _buildHeader(BuildContext context) => Padding(
    padding: const EdgeInsets.all(15),
    child: Row(
      children: [
        IconButton(icon: const Icon(Icons.arrow_back_ios_new), onPressed: () => Navigator.pop(context)),
        const Text("DELIVERY DETAILS", style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
      ],
    ),
  );
}

// --- 2. صفحة عرض الطلبات (OrdersScreen) ---
class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);
    final orders = provider.myOrders;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: TexturedBackground(
        child: Column(
          children: [
            _buildHeader(context),
            Expanded(
              child: orders.isEmpty 
                ? const Center(child: Text("NO ORDERS YET", style: TextStyle(color: Colors.grey)))
                : ListView.builder(
                    itemCount: orders.length,
                    padding: const EdgeInsets.all(15),
                    itemBuilder: (context, index) {
                      return _buildOrderCard(context, orders[index], provider);
                    },
                  ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderCard(BuildContext context, Map<String, dynamic> order, AppProvider provider) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: AppColors.textMain,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(order['id'], style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: Colors.green.withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                child: Text(order['status'], style: const TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const Divider(color: Colors.white10, height: 20),
          Text("Delivery: ${order['delivery']['address']}", style: const TextStyle(color: Colors.white70, fontSize: 12)),
          Text("Expected in: ${order['estimatedDelivery']}", style: const TextStyle(color: AppColors.primary, fontSize: 12, fontWeight: FontWeight.bold)),
          const SizedBox(height: 15),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("${order['total']} EGP", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
              
              // ✅ زر إلغاء الأوردر (أحمر)
              TextButton.icon(
                onPressed: () => _showCancelDialog(context, provider, order['id']),
                icon: const Icon(Icons.cancel, color: Colors.redAccent, size: 16),
                label: const Text("CANCEL", style: TextStyle(color: Colors.redAccent, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showCancelDialog(BuildContext context, AppProvider provider, String orderId) {
    showCupertinoDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: const Text("CANCEL ORDER?"),
        content: const Text("Are you sure you want to remove this order?"),
        actions: [
          CupertinoDialogAction(child: const Text("No"), onPressed: () => Navigator.pop(context)),
          CupertinoDialogAction(
            isDestructiveAction: true,
            child: const Text("Yes, Cancel"),
            onPressed: () {
              provider.cancelOrder(orderId);
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.all(15),
      child: Row(
        children: [
          IconButton(icon: const Icon(Icons.arrow_back_ios_new, color: AppColors.textMain), onPressed: () => Navigator.pop(context)),
          const Text("MY ORDERS", style: TextStyle(color: AppColors.textMain, fontWeight: FontWeight.w900, fontSize: 20)),
        ],
      ),
    ),
  );
}