import 'dart:convert';

import 'package:elgarage/core/constants/app_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../core/models/auth_response_model.dart';
import '../core/services/auth_service.dart';

class AuthProvider with ChangeNotifier {
  // بنستخدم السرفيس الخاصة بالباك إند بتاعنا بس
  final AuthService _authService = AuthService();
  final _storage = const FlutterSecureStorage();
  
  User? _user;
  String? _token;
  bool _isLoading = false;
  String? _errorMessage;

  User? get user => _user;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _token != null;


  // --- Login (Email/Password) ---
  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final response = await _authService.login(email, password);
      _user = response.user;
      _token = response.accessToken;
      
      await _storage.write(key: 'accessToken', value: _token);
      
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

Future<void> logout() async {
  await _storage.delete(key: 'accessToken');
  _token = null;
  _user = null;
  notifyListeners(); // ✅ هذا السطر هو المحرك لعملية الخروج
}

Future<bool> tryAutoLogin() async {
  // لا نحتاج لـ _isLoading = true هنا لأن FutureBuilder في الـ main يتعامل مع حالة الـ waiting
  try {
    _token = await _storage.read(key: 'accessToken');
    if (_token == null) return false;

    final response = await http.get(
      Uri.parse(AppConfig.profile), 
      headers: {'Authorization': 'Bearer $_token'},
    );

    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      final userData = (responseData is Map && responseData.containsKey('data')) 
          ? responseData['data'] 
          : responseData;

      _user = User.fromJson(userData);
      
      // التعديل الأهم: تحديث الواجهة في الـ Microtask القادم لتقليل الضغط
      Future.microtask(() => notifyListeners()); 
      return true;
    } else {
      await logout();
      return false;
    }
  } catch (e) {
    return false;
  }
}
  Future<bool> register(String name, String email, String phone, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    print("🚀 1. Starting Registration..."); // طباعة 1
    try {
      print("⏳ 2. Sending Request to Backend...");
      final response = await _authService.register(name, email, phone, password);
      
      print("✅ 3. Success! Token received: ${response.accessToken}");
      _user = response.user;
      _token = response.accessToken;

      await _storage.write(key: 'accessToken', value: _token);

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      print("❌ 4. Error Occurred: $e"); // هنا هنعرف السبب الحقيقي
      _isLoading = false;
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }
}