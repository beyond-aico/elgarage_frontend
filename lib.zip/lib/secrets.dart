class Secrets {
  static const String openAiApiKey = "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"; 
 static const elevenLabsApiKey = 'sk_71524af3f41753f15f834aacd0bf9db295e2d56b18534822';
  static const elevenLabsVoiceId = 'EXAVITQu4vr4xnSDxMaL'; // مثلاً من ElevenLabs Studio
  static const elevenLabsModelId = 'eleven_multilingual_v2'; // يدعم العربية

}


//wtliuexzvjxgabaq
