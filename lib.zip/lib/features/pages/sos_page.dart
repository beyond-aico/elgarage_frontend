import 'package:flutter/material.dart';

class SosPage extends StatelessWidget {
  const SosPage({super.key});

  @override
  Widget build(BuildContext context) {
    // بيانات وهمية للعرض (يمكن استبدالها لاحقاً ببيانات من الـ Models)
    final List<Map<String, dynamic>> emergencyServices = [
      {'name': 'Ambulance', 'phone': '123', 'icon': Icons.medical_services, 'color': Colors.red},
      {'name': 'Police', 'phone': '122', 'icon': Icons.local_police, 'color': Colors.blue},
      {'name': 'Fire Fighters', 'phone': '180', 'icon': Icons.fire_truck, 'color': Colors.orange},
    ];

    final List<Map<String, String>> winches = [
      {'name': 'Fast Winch Cairo', 'distance': '2 km', 'rating': '4.8'},
      {'name': 'Road Rescue Winch', 'distance': '5 km', 'rating': '4.5'},
      {'name': 'El-Nasr Towing', 'distance': '8 km', 'rating': '4.2'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Emergency & Winch", style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.redAccent,
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // زر الاستغاثة العاجلة
            Center(
              child: Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.red.withOpacity(0.1),
                  border: Border.all(color: Colors.red, width: 2),
                ),
                child: Center(
                  child: Container(
                    width: 120,
                    height: 120,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.red,
                      boxShadow: [BoxShadow(color: Colors.redAccent, blurRadius: 20, spreadRadius: 2)],
                    ),
                    child: const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.touch_app, color: Colors.white, size: 40),
                        Text("SOS", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 24)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 30),
            
            // أزرار الطوارئ السريعة
            const Text("Quick Dial", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: emergencyServices.map((service) => _buildEmergencyButton(service)).toList(),
            ),
            
            const SizedBox(height: 30),
            // قائمة الأوناش القريبة
            const Text("Nearby Winch Services", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: winches.length,
              itemBuilder: (context, index) {
                return Card(
                  elevation: 2,
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(8)),
                      child: const Icon(Icons.car_crash, color: Colors.black54),
                    ),
                    title: Text(winches[index]['name']!, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text("Distance: ${winches[index]['distance']}"),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.star, color: Colors.amber, size: 18),
                        Text(winches[index]['rating']!),
                        const SizedBox(width: 10),
                        const CircleAvatar(
                          backgroundColor: Colors.green,
                          radius: 15,
                          child: Icon(Icons.phone, color: Colors.white, size: 16),
                        )
                      ],
                    ),
                  ),
                );
              },
            )
          ],
        ),
      ),
    );
  }

  Widget _buildEmergencyButton(Map<String, dynamic> service) {
    return Column(
      children: [
        CircleAvatar(
          radius: 30,
          backgroundColor: service['color'].withOpacity(0.2),
          child: Icon(service['icon'], color: service['color'], size: 30),
        ),
        const SizedBox(height: 8),
        Text(service['name'], style: const TextStyle(fontWeight: FontWeight.w600)),
      ],
    );
  }
}