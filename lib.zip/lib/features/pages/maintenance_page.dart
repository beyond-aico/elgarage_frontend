import 'package:flutter/material.dart';

class MaintenancePage extends StatelessWidget {
  const MaintenancePage({super.key});

  @override
  Widget build(BuildContext context) {
    final workshops = [
      {'name': 'Top Gear Mechanics', 'type': 'Mechanical & Engine', 'cars': 'German Specialist', 'img': Icons.settings},
      {'name': 'Auto Electric Pro', 'type': 'Electrical & Sensors', 'cars': 'All Brands', 'img': Icons.electric_bolt},
      {'name': 'Suspension Masters', 'type': 'Chassis & Suspension', 'cars': 'Japanese Specialist', 'img': Icons.car_crash_outlined},
      {'name': 'Fix It All', 'type': 'General Repair', 'cars': 'Korean Specialist', 'img': Icons.build},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Maintenance Centers"),
        backgroundColor: Colors.blue[800],
        foregroundColor: Colors.white,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: workshops.length,
        itemBuilder: (context, index) {
          final shop = workshops[index];
          return Card(
            elevation: 4,
            margin: const EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: Column(
              children: [
                Container(
                  height: 100,
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.1),
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
                  ),
                  child: Center(
                    child: Icon(shop['img'] as IconData, size: 50, color: Colors.blue[800]),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(shop['name'] as String, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: Colors.blue[50], borderRadius: BorderRadius.circular(5)),
                            child: const Text("Open Now", style: TextStyle(color: Colors.blue, fontSize: 10, fontWeight: FontWeight.bold)),
                          )
                        ],
                      ),
                      const SizedBox(height: 5),
                      Text(shop['type'] as String, style: const TextStyle(fontSize: 14, color: Colors.grey)),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Icon(Icons.check_circle, size: 16, color: Colors.green[700]),
                          const SizedBox(width: 5),
                          Text(shop['cars'] as String, style: TextStyle(fontSize: 12, color: Colors.green[800])),
                        ],
                      ),
                      const SizedBox(height: 15),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[800],
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          child: const Text("Book Appointment"),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}