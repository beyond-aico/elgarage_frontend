import 'package:flutter/material.dart';
import 'care_page.dart';
import 'maintenance_page.dart';
import 'services_page.dart';
import 'sos_page.dart';
import 'tires_batteries.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000), // مدة أطول قليلاً لنعومة الحركة
      vsync: this,
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5), // لون خلفية هادئ
      body: Column(
        children: [
          _buildHeroHeader(),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                childAspectRatio: 0.95, // تحسين نسبة الطول للعرض
                padding: const EdgeInsets.only(top: 10, bottom: 20),
                children: [
                  _buildAnimatedCard(0, 'SOS & Winch', Icons.sos, Colors.redAccent, const SosPage()),
                  _buildAnimatedCard(1, 'Maintenance', Icons.build_circle, Colors.blueAccent, const MaintenancePage()),
                  _buildAnimatedCard(2, 'Tires & Battery', Icons.car_repair, Colors.orangeAccent, const TiresBatteriesPage()),
                  _buildAnimatedCard(3, 'Quick Service', Icons.oil_barrel, Colors.amber[700]!, const ServicesPage()),
                  _buildAnimatedCard(4, 'Car Care', Icons.cleaning_services, Colors.purpleAccent, const CarePage()),
                  _buildAnimatedCard(5, 'My Garage', Icons.garage, Colors.teal, null), // يمكن ربطها لاحقاً
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(25, 60, 25, 30),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF1E3C72), // كحلي غامق
            Color(0xFF2A5298), // أزرق أفتح
          ],
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(35),
          bottomRight: Radius.circular(35),
        ),
        boxShadow: [
          BoxShadow(color: Colors.black26, blurRadius: 15, offset: Offset(0, 8))
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: const CircleAvatar(
              radius: 28,
              backgroundColor: Colors.white24,
              child: Icon(Icons.person, color: Colors.white, size: 35),
            ),
          ),
          const SizedBox(width: 15),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Good Morning, Nour!',
                  style: TextStyle(fontSize: 16, color: Colors.white70, letterSpacing: 0.5),
                ),
                SizedBox(height: 5),
                Text(
                  'Auto Mentor',
                  style: TextStyle(
                    fontSize: 26, 
                    fontWeight: FontWeight.bold, 
                    color: Colors.white,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedCard(int index, String title, IconData icon, Color color, Widget? page) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        // حساب التأخير لكل عنصر ليظهروا بالتتابع
        double delay = index * 0.15;
        double slide = (1.0 - _controller.value) * 50;
        double opacity = (_controller.value - delay).clamp(0.0, 1.0) / (1.0 - delay).clamp(0.01, 1.0); 
        // معادلة الـ Opacity لضمان ظهور العنصر بالكامل

        return Opacity(
          opacity: opacity.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, slide),
            child: child,
          ),
        );
      },
      child: GestureDetector(
        onTap: page != null
            ? () => Navigator.push(context, MaterialPageRoute(builder: (context) => page))
            : null,
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.15),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, size: 38, color: color),
              ),
              const SizedBox(height: 15),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}