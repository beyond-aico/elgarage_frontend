import 'package:flutter/material.dart';

class ServicesPage extends StatelessWidget {
  const ServicesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Quick Maintenance"),
        backgroundColor: Colors.amber[700],
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader("Routine Checks"),
            const SizedBox(height: 10),
            _buildServiceGrid(),
            const SizedBox(height: 25),
            _buildSectionHeader("Nearby Service Stations"),
            const SizedBox(height: 10),
            _buildStationCard("Mobil 1 Center", "Oil Change & Filter", "4.9 (500 reviews)", "0.5 km"),
            _buildStationCard("Total Quartz", "Fluids Top-up", "4.7 (320 reviews)", "1.2 km"),
            _buildStationCard("Shell Helix", "Full Checkup", "4.8 (410 reviews)", "2.0 km"),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
    );
  }

  Widget _buildServiceGrid() {
    final services = [
      {'title': 'Engine Oil', 'icon': Icons.oil_barrel, 'color': Colors.amber},
      {'title': 'Filters', 'icon': Icons.filter_alt, 'color': Colors.grey},
      {'title': 'Brake Fluid', 'icon': Icons.water_drop, 'color': Colors.redAccent},
      {'title': 'Wipers', 'icon': Icons.wifi_protected_setup, 'color': Colors.blue},
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.5,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      itemCount: services.length,
      itemBuilder: (context, index) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(services[index]['icon'] as IconData, size: 30, color: services[index]['color'] as Color),
              const SizedBox(height: 8),
              Text(services[index]['title'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStationCard(String name, String specialty, String rating, String dist) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Colors.amber[100],
          child: Icon(Icons.local_gas_station, color: Colors.amber[800]),
        ),
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text("$specialty • $dist"),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.star, color: Colors.amber, size: 16),
            Text(rating, style: const TextStyle(fontSize: 10)),
          ],
        ),
      ),
    );
  }
}