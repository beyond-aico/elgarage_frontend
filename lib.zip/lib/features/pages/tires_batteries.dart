import 'package:flutter/material.dart';

class TiresBatteriesPage extends StatelessWidget {
  const TiresBatteriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Tires & Batteries"),
          backgroundColor: Colors.orange,
          foregroundColor: Colors.white,
          bottom: const TabBar(
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: [
              Tab(icon: Icon(Icons.circle_outlined), text: "Tires Services"),
              Tab(icon: Icon(Icons.battery_charging_full), text: "Battery Services"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildServiceList([
              {'name': 'Fit & Fix', 'desc': 'Tire repair & Air pressure', 'loc': 'Nasr City', 'status': 'Open'},
              {'name': 'Bridgestone Center', 'desc': 'New tires & alignment', 'loc': 'Maadi', 'status': 'Closing Soon'},
              {'name': 'Local Tire Shop', 'desc': 'Quick puncture fix', 'loc': 'Nearby', 'status': 'Open 24/7'},
            ], Icons.circle_outlined, Colors.black87),
            
            _buildServiceList([
              {'name': 'Battery Pro', 'desc': 'Jump start & Replacement', 'loc': 'Heliopolis', 'status': 'Open'},
              {'name': 'Varta Authorized', 'desc': 'New Batteries', 'loc': 'Downtown', 'status': 'Open'},
              {'name': 'Mobile Battery Van', 'desc': 'Comes to your location', 'loc': 'Anywhere', 'status': 'Available'},
            ], Icons.battery_alert, Colors.orange),
          ],
        ),
      ),
    );
  }

  Widget _buildServiceList(List<Map<String, String>> items, IconData icon, Color color) {
    return ListView.builder(
      padding: const EdgeInsets.all(15),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return Card(
          elevation: 3,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          margin: const EdgeInsets.only(bottom: 15),
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: color, size: 30),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item['name']!, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 5),
                      Text(item['desc']!, style: TextStyle(color: Colors.grey[600])),
                      const SizedBox(height: 5),
                      Row(
                        children: [
                          const Icon(Icons.location_on, size: 14, color: Colors.grey),
                          const SizedBox(width: 4),
                          Text(item['loc']!, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: item['status'] == 'Open' || item['status'] == 'Available' 
                                  ? Colors.green.withOpacity(0.1) 
                                  : Colors.orange.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: Text(
                              item['status']!,
                              style: TextStyle(
                                color: item['status'] == 'Open' || item['status'] == 'Available' 
                                    ? Colors.green 
                                    : Colors.orange,
                                fontSize: 12,
                                fontWeight: FontWeight.bold
                              ),
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}