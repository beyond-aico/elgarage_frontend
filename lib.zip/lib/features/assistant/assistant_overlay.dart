import 'package:flutter/material.dart';
import 'package:chat_bubbles/chat_bubbles.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:loading_animation_widget/loading_animation_widget.dart';
import '../../core/constants/app_colors.dart';
import '../../core/ai/assistant_service.dart';
import '../../core/ai/voice_triggers.dart';

class AssistantOverlay extends StatefulWidget {
  const AssistantOverlay({super.key});

  @override
  State<AssistantOverlay> createState() => _AssistantOverlayState();
}

class _AssistantOverlayState extends State<AssistantOverlay> {
  // Services
  final OpenAIService _aiService = OpenAIService();
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _flutterTts = FlutterTts();

  // State
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<Map<String, dynamic>> messages = [];
  bool _isListening = false;
  bool _isLoading = false;
  bool _isExpanded = false; // للتحكم في فتح/غلق الشات

  @override
  void initState() {
    super.initState();
    _initTts();
    // رسالة ترحيبية
    messages.add({
      'isUser': false,
      'text': 'أهلاً يا هندسة! 🚗\nمعاك أوتو مينتور، أؤمرني؟'
    });
  }

  void _initTts() async {
  }

  // --- Logic ---

  void _handleSend(String text) async {
    if (text.trim().isEmpty) return;

    // 1. فحص الأوامر الصوتية أولاً (Voice Triggers)
    // نمرر الـ navigator context
    bool isCommand = VoiceTriggers.handleCommand(text, context);
    
    if (isCommand) {
      // لو كان أمر انتقال، نغلق الشات فوراً
      setState(() => _isExpanded = false);
      return; 
    }

    // 2. محادثة عادية مع الذكاء الاصطناعي
    setState(() {
      messages.add({'isUser': true, 'text': text});
      _isLoading = true;
    });
    _scrollToBottom();
    _textController.clear();

    final response = await _aiService.getResponse(text);

    if (!mounted) return;
    setState(() {
      _isLoading = false;
      messages.add({'isUser': false, 'text': response});
    });
    _scrollToBottom();
    _flutterTts.speak(response);
  }

  void _toggleListening() async {
    if (!_isListening) {
      bool available = await _speech.initialize();
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(
          onResult: (val) {
            _textController.text = val.recognizedWords;
            if (val.finalResult) {
              setState(() => _isListening = false);
              _handleSend(val.recognizedWords); // إرسال تلقائي عند التوقف
            }
          },
          localeId: 'ar_EG',
        );
      }
    } else {
      setState(() => _isListening = false);
      _speech.stop();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // --- UI ---

  @override
  Widget build(BuildContext context) {
    // نستخدم Material لضمان ظهور العناصر بشكل صحيح داخل الـ Overlay
    return Stack(
      children: [
        // 1. نافذة الشات (خلفية معتمة تظهر عند الفتح)
        if (_isExpanded)
          Positioned.fill(
            child: GestureDetector(
              onTap: () => setState(() => _isExpanded = false), // إغلاق عند الضغط خارجاً
              child: Container(
                color: Colors.black54,
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: GestureDetector(
                    onTap: () {}, // منع الإغلاق عند الضغط داخل الشات
                    child: Container(
                      height: MediaQuery.of(context).size.height * 0.75,
                      margin: const EdgeInsets.only(bottom: 90, left: 10, right: 10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: const [BoxShadow(blurRadius: 10, color: Colors.black26)],
                      ),
                      child: Column(
                        children: [
                          // Header
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            decoration: BoxDecoration(
                              color: AppColors.primary,
                              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.smart_toy, color: Colors.white),
                                const SizedBox(width: 8),
                                const Text("المساعد الذكي", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                                const Spacer(),
                                IconButton(
                                  icon: const Icon(Icons.close, color: Colors.white),
                                  onPressed: () => setState(() => _isExpanded = false),
                                )
                              ],
                            ),
                          ),
                          
                          // Chat Body
                          Expanded(
                            child: ListView.builder(
                              controller: _scrollController,
                              padding: const EdgeInsets.all(10),
                              itemCount: messages.length,
                              itemBuilder: (context, index) {
                                final msg = messages[index];
                                return BubbleSpecialThree(
                                  text: msg['text'],
                                  color: msg['isUser'] ? AppColors.primary.withOpacity(0.9) : const Color(0xFFE0E0E0),
                                  tail: true,
                                  isSender: msg['isUser'],
                                  textStyle: TextStyle(
                                    color: msg['isUser'] ? Colors.white : Colors.black87,
                                    fontSize: 15,
                                    fontFamily: 'Tajawal',
                                  ),
                                );
                              },
                            ),
                          ),

                          // Loading
                          if (_isLoading)
                             Padding(
                               padding: const EdgeInsets.all(8.0),
                               child: LoadingAnimationWidget.waveDots(color: AppColors.primary, size: 30),
                             ),

                          // Input Bar
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.grey[100],
                              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(20)),
                            ),
                            child: Row(
                              children: [
                                FloatingActionButton.small(
                                  onPressed: _toggleListening,
                                  backgroundColor: _isListening ? Colors.red : AppColors.secondary,
                                  child: Icon(_isListening ? Icons.stop : Icons.mic, color: Colors.white),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: TextField(
                                    controller: _textController,
                                    decoration: InputDecoration(
                                      hintText: "اكتب أو اسأل صوتياً...",
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(30),
                                        borderSide: BorderSide.none
                                      ),
                                      filled: true,
                                      fillColor: Colors.white,
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 15),
                                    ),
                                    onSubmitted: _handleSend,
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.send, color: AppColors.primary),
                                  onPressed: () => _handleSend(_textController.text),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

        // 2. الزر العائم الثابت (يظهر دائماً)
        Positioned(
          bottom: 20,
          left: 20, // أو right حسب تفضيلك
          child: FloatingActionButton(
            onPressed: () {
              setState(() {
                _isExpanded = !_isExpanded;
              });
            },
            backgroundColor: AppColors.primary,
            child: Icon(_isExpanded ? Icons.keyboard_arrow_down : Icons.smart_toy, size: 30, color: Colors.white),
          ),
        ),
      ],
    );
  }
}