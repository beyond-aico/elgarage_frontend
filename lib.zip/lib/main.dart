import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_core/firebase_core.dart';
// تأكد من صحة المسارات بناءً على هيكليتك
import 'features/pages/home_page.dart'; 
import 'features/assistant/assistant_overlay.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (e) {
    debugPrint("Firebase Error: $e");
  }
  runApp(const AutoMentorApp());
}

class AutoMentorApp extends StatelessWidget {
  const AutoMentorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Auto Mentor',
      debugShowCheckedModeBanner: false,
      
      // إعدادات الثيم والخطوط
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2563EB), 
          background: const Color(0xFFF8FAFC),
        ),
        textTheme: GoogleFonts.tajawalTextTheme(),
        // أنيميشن الانتقال بين الصفحات
        pageTransitionsTheme: const PageTransitionsTheme(
          builders: {
            TargetPlatform.android: ZoomPageTransitionsBuilder(),
            TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          },
        ),
      ),

      // دعم اللغة العربية
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],

      // هنا يتم وضع المساعد ليكون فوق التطبيق بالكامل
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Stack(
            children: [
              // 1. التطبيق الأصلي (الصفحات)
              if (child != null) child,
              
              // 2. طبقة المساعد الذكي العائمة (تعمل في كل الصفحات)
              const AssistantOverlay(),
            ],
          ),
        );
      },

      home: const HomePage(),
    );
  }
}