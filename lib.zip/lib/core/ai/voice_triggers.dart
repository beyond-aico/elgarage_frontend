import 'package:flutter/material.dart';
import '../../features/pages/tires_batteries.dart';
import '../../features/pages/services_page.dart';
import '../../features/pages/maintenance_page.dart';
import '../../features/pages/care_page.dart';
import '../../features/pages/sos_page.dart';

class VoiceTriggers {
  // تعريف القوائم لتسهيل التوسع مستقبلاً
  static const List<String> sosKeywords = [
    'sos', 'ونش', 'نجدة', 'الحقني', 'عطلان', 'حادثة', 'اسعاف', 'شرطة', 'طوارئ', 'غرزت', 
    'help', 'emergency', 'rescue', 'tow', 'winch'
  ];

  static const List<String> serviceKeywords = [
    'زيت', 'زيوت', 'فلتر', 'مياه', 'تبريد', 'مساحات', 'تيل', 'فرامل', 
    'oil', 'filter', 'fluid', 'wipers', 'pads', 'quick service'
  ];

  static const List<String> tiresKeywords = [
    'كاوتش', 'عجلة', 'عجل', 'نايمة', 'مخرومة', 'بنشر', 'لحام', 
    'بطارية', 'شحن', 'توصيلة', 'فردة', 
    'tire', 'battery', 'flat tire', 'puncture', 'jump start'
  ];

  static const List<String> maintenanceKeywords = [
    'صيانة', 'مركز', 'ميكانيكي', 'عفشة', 'كهربائي', 'سمكري', 'دوكو', 'موتور', 'فتيس', 
    'ورشة', 'تصليح', 
    'mechanic', 'repair', 'workshop', 'maintenance', 'engine'
  ];

  static const List<String> careKeywords = [
    'غسيل', 'نظافة', 'تلميع', 'بوليش', 'كار كير', 'زينة', 'كماليات', 'فاميه', 'فرش',
    'wash', 'clean', 'detailing', 'polish', 'accessories'
  ];

  /// دالة للتحقق من النص وتنفيذ الانتقال
  static bool handleCommand(String text, BuildContext context) {
    String cleanedText = text.toLowerCase();

    // 1. SOS & Winch
    if (sosKeywords.any((word) => cleanedText.contains(word))) {
      _navigate(context, const SosPage());
      return true;
    }

    // 2. Quick Services (Oil & Filter)
    if (serviceKeywords.any((word) => cleanedText.contains(word))) {
      _navigate(context, const ServicesPage());
      return true;
    }

    // 3. Tires & Batteries
    if (tiresKeywords.any((word) => cleanedText.contains(word))) {
      _navigate(context, const TiresBatteriesPage());
      return true;
    }

    // 4. Maintenance Centers
    if (maintenanceKeywords.any((word) => cleanedText.contains(word))) {
      _navigate(context, const MaintenancePage());
      return true;
    }
    
    // 5. Car Care
    if (careKeywords.any((word) => cleanedText.contains(word))) {
      _navigate(context, const CarePage());
      return true;
    }

    return false; // لم يتم العثور على أمر
  }

  static void _navigate(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }
}