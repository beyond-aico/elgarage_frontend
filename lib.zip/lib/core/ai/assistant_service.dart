import 'dart:convert';
import 'package:http/http.dart' as http;
import 'system_prompt.dart';

class OpenAIService {
  // ⚠️ استبدل هذا بمفتاحك الحقيقي، ولا ترفعه على GitHub
  static const String _apiKey = 'sk-YOUR_OPENAI_API_KEY_HERE';
  static const String _baseUrl = 'https://api.openai.com/v1/chat/completions';

  Future<String> getResponse(String userMessage) async {
    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Content-Type': 'application/json; charset=utf-8', // مهم لدعم العربي
          'Authorization': 'Bearer $_apiKey',
        },
        body: jsonEncode({
          "model": "gpt-4o-mini", // الموديل الاقتصادي والذكي
          "messages": [
            {"role": "system", "content": SystemPrompts.carConsultant},
            {"role": "user", "content": userMessage}
          ],
          "temperature": 0.7, // إبداع متوازن
          "max_tokens": 150,  // لتقليل التكلفة وسرعة الرد
        }),
      );

      if (response.statusCode == 200) {
        // فك التشفير بصيغة UTF-8 لضمان ظهور العربي بشكل صحيح
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        return data['choices'][0]['message']['content'];
      } else {
        return "معلش يا هندسة، السيرفر مهنج شوية (Error: ${response.statusCode})";
      }
    } catch (e) {
      return "فيه مشكلة في النت يا كبير، اتأكد من الوصلة.";
    }
  }
}