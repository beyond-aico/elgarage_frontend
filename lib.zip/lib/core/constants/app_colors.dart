import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF0D47A1); // أزرق ملكي
  static const Color secondary = Color(0xFF1976D2);
  static const Color accent = Color(0xFFE3F2FD);
  static const Color sosRed = Color(0xFFD32F2F); // لون الـ SOS المميز
  static const Color textDark = Color(0xFF212121);
  static const Color textLight = Color(0xFF757575);
  static const Color background = Color(0xFFF5F7FA); // خلفية رمادي فاتح جداً
}