import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/ai/assistant_service.dart';

class AssistantFab extends StatefulWidget {
  final VoiceAssistant va;
  // 1. إضافة مفتاح النافيجيتور هنا
  final GlobalKey<NavigatorState> navKey; 

  const AssistantFab({
    super.key, 
    required this.va, 
    required this.navKey
  });

  @override
  State<AssistantFab> createState() => _AssistantFabState();
}

class _AssistantFabState extends State<AssistantFab> with SingleTickerProviderStateMixin {
  OverlayEntry? _overlayEntry;
  late final AnimationController _animationController;
  late final Animation<Offset> _slideAnimation;

  VoiceAssistant get _va => widget.va;

  void _onVaChanged() { if (mounted) setState(() {}); }

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic));
    _va.addListener(_onVaChanged);
  }

  @override
  void dispose() {
    _va.removeListener(_onVaChanged);
    _animationController.dispose();
    _removeOverlay();
    super.dispose();
  }

  void _toggleOverlay() {
    if (_overlayEntry != null) {
      _closePanel();
    } else {
      _openPanel();
    }
  }

  void _openPanel() {
    if (_overlayEntry != null) return;
    
    // 2. استخدام navKey للوصول للـ Overlay بدلاً من context
    final overlay = widget.navKey.currentState?.overlay;
    if (overlay == null) return;

    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        bottom: 90.0,
        right: 16.0, // أو left حسب اللغة
        child: FadeTransition(
          opacity: _animationController,
          child: SlideTransition(
            position: _slideAnimation,
            child: _AssistantPanel(va: _va, onClose: _closePanel),
          ),
        ),
      ),
    );

    // إدراج البانل في الـ Overlay
    overlay.insert(_overlayEntry!);
    _animationController.forward();
    _va.stopAll(); 
  }

Future<void> _closePanel() async {
    // 2. نفس الفحص هنا قبل ما نحاول نقفل
    if (_overlayEntry == null || !_overlayEntry!.mounted) return;
    
    _va.stopAll();
    await _animationController.reverse();
    _removeOverlay();
  }
// في ملف lib/features/assistant/assistant_fab.dart

  void _removeOverlay() {
    // 1. التأكد إن المتغير مش null وإنه فعلاً مركب (mounted)
    if (_overlayEntry != null && _overlayEntry!.mounted) {
      _overlayEntry?.remove();
    }
    _overlayEntry = null;
  }

  @override
  Widget build(BuildContext context) {
    bool isBusy = _va.isListening || _va.isSpeaking || _va.isProcessing;
    return FloatingActionButton.extended(
      heroTag: 'assistant_fab',
      onPressed: _toggleOverlay,
      backgroundColor: isBusy ? Colors.redAccent : const Color.fromARGB(255, 0, 0, 0),
      icon: Icon(isBusy ? Icons.graphic_eq : Icons.mic, color: Colors.white),
      label: Text(
        isBusy ? 'Auto Mentor...' : 'المساعد', 
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)
      ),
    );
  }
}

class _AssistantPanel extends StatefulWidget {
  final VoiceAssistant va;
  final VoidCallback onClose;
  const _AssistantPanel({required this.va, required this.onClose});

  @override
  State<_AssistantPanel> createState() => _AssistantPanelState();
}

class _AssistantPanelState extends State<_AssistantPanel> {
  String _liveTranscript = '';
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    widget.va.addListener(_scrollDown);
  }
  
  void _scrollDown() {
    if(mounted) setState(() {});
    WidgetsBinding.instance.addPostFrameCallback((_) {
       if (_scrollController.hasClients) {
        _scrollController.animateTo(_scrollController.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
       }
    });
  }

  @override
  void dispose() {
    widget.va.removeListener(_scrollDown);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final va = widget.va;
    return Material(
      elevation: 8,
      borderRadius: BorderRadius.circular(16),
      color: Colors.white,
      child: Container(
        width: 320,
        height: 450,
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(children: [
              const Text("Auto Mentor Chat", style: TextStyle(fontWeight: FontWeight.bold)),
              const Spacer(),
              IconButton(icon: const Icon(Icons.close), onPressed: widget.onClose)
            ]),
            const Divider(),
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                itemCount: va.chatHistory.length,
                itemBuilder: (ctx, i) {
                  final msg = va.chatHistory[i];
                  final isUser = msg['sender'] == 'user';
                  return Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: isUser ? Colors.blue[100] : Colors.grey[200],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(msg['text'] ?? ''),
                    ),
                  );
                },
              ),
            ),
            if (va.isListening && _liveTranscript.isNotEmpty)
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(_liveTranscript, style: const TextStyle(color: Colors.grey, fontStyle: FontStyle.italic)),
              ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                   if(va.isListening) {
                     va.stopAll();
                   } else {
                     // تمرير context بشكل صحيح
                     va.startListening((_) {}, context, onPartialResult: (p) => setState(() => _liveTranscript = p));
                   }
                },
                icon: Icon(va.isListening ? Icons.stop : Icons.mic),
                label: Text(va.isListening ? "جاري الاستماع..." : "اضغط للتحدث"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: va.isListening ? Colors.red : Colors.blue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}