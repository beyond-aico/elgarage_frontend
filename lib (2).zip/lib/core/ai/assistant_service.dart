import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:dart_openai/dart_openai.dart';
import '../../secrets.dart';
import 'voice_triggers.dart' as vt;
import 'tts.dart';
import 'chat_logger.dart'; // تأكد إن الملف ده موجود زي ما هو عندك
import 'system_prompt.dart';

class VoiceAssistant extends ChangeNotifier {
  late stt.SpeechToText _speech;
  final String userId;
  final String sessionId;
  late final ChatLogger _logger; // استخدام الـ Logger القديم بتاعك أو اللي في الكود الجديد

  bool _isListening = false;
  bool _isSpeaking = false;
  bool _isProcessing = false;
  bool _isStopped = false;
  bool autoResumeAfterSpeak = false;

  bool get isListening => _isListening;
  bool get isSpeaking => _isSpeaking;
  bool get isProcessing => _isProcessing;

  final ElevenLabsTTS _tts = ElevenLabsTTS(
    apiKey: Secrets.elevenLabsApiKey,
    voiceId: Secrets.elevenLabsVoiceId,
    modelId: Secrets.elevenLabsModelId,
  );

  final List<Map<String, String>> chatHistory = [];
  void Function(String route)? onRouteDetected; // Callback للتنقل

  VoiceAssistant({required this.userId, required this.sessionId}) {
    _speech = stt.SpeechToText();
    OpenAI.apiKey = Secrets.openAiApiKey;
    _logger = ChatLogger(); // تهيئة الـ Logger
  }

  void stopAll() {
    try { if (_isListening) _speech.stop(); if (_isSpeaking) _tts.stop(); } catch (_) {}
    _isListening = false;
    _isSpeaking = false;
    _isProcessing = false;
    _isStopped = true;
    notifyListeners();
  }

  void activate() {
    _isStopped = false;
  }

  Future<void> startListening(Function(String) onFinalResult, BuildContext context, {Function(String)? onPartialResult}) async {
    if (_isSpeaking || _isProcessing || _isListening) return;
    _isStopped = false;

    bool available = await _speech.initialize();
    if (!available) return;

    _isListening = true;
    notifyListeners();

    _speech.listen(
      onResult: (val) {
        onPartialResult?.call(val.recognizedWords);
        
        if (val.finalResult && val.recognizedWords.isNotEmpty) {
          _isListening = false;
          notifyListeners();
          onFinalResult(val.recognizedWords);
          _processRequest(val.recognizedWords, context);
        }
      },
      localeId: 'ar-EG',
      pauseFor: const Duration(seconds: 3),
    );
  }

  Future<void> _processRequest(String userQuery, BuildContext context) async {
    _isProcessing = true;
    notifyListeners();

    // 1. Check Routing Logic
    final intent = vt.detectRouteIntent(userQuery);
    if (intent.route != null) {
      chatHistory.add({"sender": "user", "text": userQuery});
      String reply = "تمام يا هندسة، جاري الفتح.";
      chatHistory.add({"sender": "assistant", "text": reply});
      
      onRouteDetected?.call(intent.route!); // Trigger Navigation
      
      await _tts.speak(reply, onComplete: () {
        _isProcessing = false;
        notifyListeners();
      });
      return;
    }

    // 2. OpenAI Chat Logic
    chatHistory.add({"sender": "user", "text": userQuery});
    _logger.logMessage(userMessage: userQuery, aiResponse: "..."); // Log

    try {
      final systemMessage = OpenAIChatCompletionChoiceMessageModel(
        role: OpenAIChatMessageRole.system,
        content: [OpenAIChatCompletionChoiceMessageContentItemModel.text(SystemPrompts.carConsultant)],
      );

      final userMessage = OpenAIChatCompletionChoiceMessageModel(
        role: OpenAIChatMessageRole.user,
        content: [OpenAIChatCompletionChoiceMessageContentItemModel.text(userQuery)],
      );

      final chatCompletion = await OpenAI.instance.chat.create(
        model: "gpt-4o-mini",
        messages: [systemMessage, userMessage],
      );

      String response = chatCompletion.choices.first.message.content?.first.text ?? "معلش مسمعتش كويس";
      
      chatHistory.add({"sender": "assistant", "text": response});
      _logger.logMessage(userMessage: userQuery, aiResponse: response); // Update Log

      _isProcessing = false;
      notifyListeners();

      await _tts.speak(response, onComplete: () {
        if (autoResumeAfterSpeak && !_isStopped) {
           // Auto resume logic if needed
        }
      });

    } catch (e) {
      _isProcessing = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _speech.cancel();
    _tts.dispose();
    super.dispose();
  }
}