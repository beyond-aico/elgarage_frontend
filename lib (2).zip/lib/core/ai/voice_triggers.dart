library;

/// كلمات الاستيقاظ (Wake Words)
const List<String> kWakeWords = [
  'يا اوتو', 'يا مينتور', 'يا هندسة', 'يا اسطى', 'يا كابتن',
  'hey auto', 'auto mentor', 'mentor',
];

String _norm(String s) => _normalizeArabic(s.toLowerCase().trim());

String _normalizeArabic(String s) {
  const alif = ['أ','إ','آ','ٱ'];
  for (final a in alif) { s = s.replaceAll(a, 'ا'); }
  s = s.replaceAll('ى', 'ي').replaceAll('ة', 'ه')
       .replaceAll('ؤ', 'و').replaceAll('ئ', 'ي').replaceAll('ـ', '');
  s = s.replaceAll(RegExp(r'[\u064B-\u065F]'), ''); // تشكيل
  s = s.replaceAll(RegExp(r'\s+'), ' ');
  return s.trim();
}

class WakeDetectResult {
  final bool matched;
  final String cleanedUtterance;
  const WakeDetectResult({required this.matched, required this.cleanedUtterance});
}

WakeDetectResult detectWakeWord(String utterance) {
  final s = _norm(utterance);
  for (final w in kWakeWords) {
    final ww = _norm(w);
    if (s.startsWith(ww)) {
      final cleaned = s.replaceFirst(RegExp('^${RegExp.escape(ww)}\\s*'), '').trimLeft();
      return WakeDetectResult(matched: true, cleanedUtterance: cleaned);
    }
  }
  return const WakeDetectResult(matched: false, cleanedUtterance: '');
}

/// =============================
/// خريطة التوجيه (Routing Map)
/// =============================
const Map<String, List<String>> _routeKeywords = {
  '/sos': ['نجدة','ونش','عطلان','الحقني','حادثة','اسعاف','شرطة','غرزت','sos','help','tow'],
  '/maintenance': ['صيانة','مركز','ورشة','ميكانيكي','عفشة','كهربائي','سمكري','فتيس','موتور'],
  '/tires': ['كاوتش','عجلة','نايمة','مخرومة','بنشر','لحام','بطارية','شحن','توصيلة'],
  '/services': ['زيت','فلتر','مياه','تبريد','مساحات','تيل','فرامل','صيانة دورية'],
  '/care': ['غسيل','نظافة','تلميع','بوليش','كار كير','زينة','كماليات','فاميه','فرش'],
};

/// أفعال التوجيه (Navigate Verbs) لحذفها قبل البحث
final List<RegExp> _navVerbs = [
  RegExp(r'^(روح(ي)?|اذهب(ي)?|افتح(ي)?|وديني|خدني|وريني|عايز|عاوزه|هات|navigate to|open|show me)\s+', caseSensitive: false),
];

String _stripNavVerb(String s) {
  var out = _norm(s);
  for (final rx in _navVerbs) { out = out.replaceFirst(rx, ''); }
  return out.trim();
}

class RouteMatch {
  final String? route;
  final String cleanedUtterance;
  const RouteMatch({required this.route, required this.cleanedUtterance});
}

RouteMatch detectRouteIntent(String utterance) {
  final cleaned = _stripNavVerb(utterance);
  final s = _norm(cleaned);
  
  for (final entry in _routeKeywords.entries) {
    for (final kw in entry.value) {
      final k = _norm(kw);
      if (s.contains(k)) {
        return RouteMatch(route: entry.key, cleanedUtterance: cleaned);
      }
    }
  }
  return RouteMatch(route: null, cleanedUtterance: cleaned);
}