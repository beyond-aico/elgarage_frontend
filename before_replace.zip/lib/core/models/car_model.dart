class Car {
  final String id;
  final String make;
  final String model;
  final int year;
  final String? licensePlate;
  final String? color;
  final String? vin;
  final String? imageUrl;
  final int currentKm; // سنبقي الاسم currentKm لتقليل أخطاء الـ UI

  Car({
    required this.id,
    required this.make,
    required this.model,
    required this.year,
    this.licensePlate,
    this.color,
    this.vin,
    this.imageUrl,
    this.currentKm = 0,
  });

  Car copyWith({
    String? id,
    String? make,
    String? model,
    int? year,
    String? licensePlate,
    String? color,
    String? vin,
    String? imageUrl,
    int? currentKm,
  }) {
    return Car(
      id: id ?? this.id,
      make: make ?? this.make,
      model: model ?? this.model,
      year: year ?? this.year,
      licensePlate: licensePlate ?? this.licensePlate,
      color: color ?? this.color,
      vin: vin ?? this.vin,
      imageUrl: imageUrl ?? this.imageUrl,
      currentKm: currentKm ?? this.currentKm,
    );
  }

  factory Car.fromJson(Map<String, dynamic> json) {
    // تعريف المتغيرات التي كانت ناقصة في التشخيص
    String makeData = 'Unknown Make';
    String modelData = 'Unknown Model';

    if (json['model'] != null && json['model'] is Map) {
      modelData = json['model']['name'] ?? 'Unknown Model';
      if (json['model']['brand'] != null && json['model']['brand'] is Map) {
        makeData = json['model']['brand']['name'] ?? 'Unknown Make';
      }
    } else {
      makeData = json['make'] ?? 'Unknown Make';
      modelData = json['model'] is String ? json['model'] : 'Unknown Model';
    }

    final dynamic rawKm = json['mileageKm'] ?? json['currentKm'] ?? json['mileage'] ?? 0;
    final int finalKm = (rawKm is num) ? rawKm.toInt() : int.tryParse(rawKm.toString()) ?? 0;

    return Car(
      id: json['id']?.toString() ?? '',
      make: makeData,
      model: modelData,
      year: json['year'] ?? 2024,
      licensePlate: json['plateNumber'] ?? json['licensePlate'],
      color: json['color'],
      vin: json['vin'],
      imageUrl: json['imageUrl'] ?? '',
      currentKm: finalKm,
    );
  }
}