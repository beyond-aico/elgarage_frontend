import 'dart:convert';
import 'package:elgarage/core/constants/app_config.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ApiService {
  final _storage = const FlutterSecureStorage();
  final String baseUrl = AppConfig.baseUrl; // تأكد من تعريف baseUrl في AppConfig

  Future<Map<String, String>> _getAuthHeaders() async {
    String? token = await _storage.read(key: 'jwt_token');
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  // --- لوحة تحكم المدير (Fleet Dashboard) ---
  Future<Map<String, dynamic>> getFleetDashboard() async {
    final response = await http.get(
      Uri.parse('$baseUrl/admin/reports/fleet/dashboard'),
      headers: await _getAuthHeaders(),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body)['data'];
    }
    throw Exception('Failed to load fleet analytics');
  }

  // --- التحقق من الباركود (Driver Login via QR) ---
  Future<Map<String, dynamic>> verifyBarcode(String barcode) async {
    final response = await http.post(
      Uri.parse('$baseUrl/fleet/auth-barcode'),
      headers: await _getAuthHeaders(),
      body: jsonEncode({'barcode': barcode}),
    );
    if (response.statusCode == 201 || response.statusCode == 200) {
      return jsonDecode(response.body)['data'];
    }
    throw Exception('Invalid Barcode or unauthorized access');
  }

  // --- تسجيل الوقود والعداد (End of Day) ---
  Future<void> addFuelLog(Map<String, dynamic> logData) async {
    final response = await http.post(
      Uri.parse('$baseUrl/fleet/logs'),
      headers: await _getAuthHeaders(),
      body: jsonEncode(logData),
    );
    if (response.statusCode != 201) {
      final error = jsonDecode(response.body);
      throw Exception(error['message'] ?? 'Failed to submit log');
    }
  }

  // --- جلب حالة الصيانة للسيارة ---
  Future<List<dynamic>> getCarMaintenanceStatus(String carId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/maintenance/status/$carId'),
      headers: await _getAuthHeaders(),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body)['data'];
    }
    throw Exception('Failed to fetch maintenance status');
  }
}