// --- FILE: lib/core/services/car_service.dart ---

import 'dart:convert';
import 'package:elgarage/core/constants/app_config.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../models/car_model.dart';
import 'package:flutter/foundation.dart';

class CarService {
  final String baseUrl = AppConfig.baseUrl; 
final _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(
      sharedPreferencesName: 'ElGarage_Secure_Final',
    ),
  );
  // جلب التوكن من التخزين الآمن
  Future<String?> _getToken() async => await _storage.read(key: 'accessToken');

void _checkUnauthorized(http.Response response) {
  if (response.statusCode == 401) {
    debugPrint("🚫 Unauthorized! Token expired or invalid.");
    throw Exception('UNAUTHORIZED'); 
  }
}

  // إعداد الهيدر الموحد للطلبات
  Future<Map<String, String>> _getHeaders() async {
    final token = await _getToken();
    return {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
  }

  // 1. جلب سيارات الأسطول (للمديرين)
  Future<List<Car>> getFleetCars() async {
    final response = await http.get(
      Uri.parse('$baseUrl/cars/fleet'),
      headers: await _getHeaders(),
    );
_checkUnauthorized(response); // ✅ أضف هذا السطر هنا
    if (response.statusCode == 200) {
      final dynamic decodedBody = json.decode(response.body);
      final List<dynamic> data = decodedBody is Map ? (decodedBody['data'] ?? []) : decodedBody;
      return data.map((json) => Car.fromJson(json)).toList();
    }
    return [];
  }

 Future<List<Car>> getMyCars() async {
  try {
    final response = await http.get(
      Uri.parse('$baseUrl/cars'),
      headers: await _getHeaders(),
    );

    _checkUnauthorized(response); // ✅ فحص التوكن أولاً

    if (response.statusCode == 200) {
      final dynamic decodedBody = json.decode(response.body);
      final List<dynamic> data = decodedBody is Map ? (decodedBody['data'] ?? []) : decodedBody;
      return data.map((json) => Car.fromJson(json)).toList();
    }
    return [];
  } catch (e) {
    if (e.toString().contains('UNAUTHORIZED')) rethrow; // عشان الـ Provider يحس بيها
    return [];
  }
}

// 1. جلب الماركات (Brands)
Future<List<dynamic>> getBrands() async {
  final url = '$baseUrl/admin/brands'; // المسار الجديد
  try {
    final response = await http.get(Uri.parse(url), headers: await _getHeaders());
    if (response.statusCode == 200) {
      final body = json.decode(response.body);
      // NestJS بيلف الداتا في حقل data بسبب الـ Interceptor
      return body['data'] ?? body; 
    }
    _checkUnauthorized(response); // ✅ أضف هذا السطر هنا
  } catch (e) {
    debugPrint("❌ Error fetching brands: $e");
  }
  return [];
}

// 2. جلب الموديلات (Models)
Future<List<dynamic>> getModels(String brandId) async {
  // استخدام الـ Query Parameter كما حددنا في الباك إند (?brandId=)
  final url = '$baseUrl/admin/brands/models?brandId=$brandId';
  try {
    final response = await http.get(Uri.parse(url), headers: await _getHeaders());
    if (response.statusCode == 200) {
      final body = json.decode(response.body);
      return body['data'] ?? body;
    }
    _checkUnauthorized(response); // ✅ أضف هذا السطر هنا
  } catch (e) {
    debugPrint("❌ Error fetching models: $e");
  }
  return [];
}

 // --- FILE: lib/core/services/car_service.dart ---

// lib/core/services/car_service.dart

Future<void> addCar(Map<String, dynamic> carData) async {
  final payload = {
    "modelId": carData['modelId'],
    "year": carData['year'],
    "color": carData['color'],
    "mileageKm": carData['mileageKm'], // ✅ التأكد من استخدام mileageKm
    "plateNumber": carData['plateNumber'] ?? "No Plate"
  };

  final response = await http.post(
    Uri.parse('$baseUrl/cars'),
    headers: await _getHeaders(),
    body: jsonEncode(payload),
  );
  
  _checkUnauthorized(response);
  if (response.statusCode != 201 && response.statusCode != 200) {
    throw Exception('Failed to add car: ${response.body}');
  }
}

// 1. تحديث جلب الصيانات المستحقة (الحالة الصحية للسيارة)
Future<List<dynamic>> getDueMaintenance(String carId) async {
  final token = await _getToken();
  try {
    // تم تغيير المسار إلى /maintenance/status/ ليتوافق مع الباك إند الجديد
    final response = await http.get(
      Uri.parse('$baseUrl/maintenance/status/$carId'), 
      headers: {'Authorization': 'Bearer $token'},
    );
    
    _checkUnauthorized(response);

    if (response.statusCode == 200) {
      final body = json.decode(response.body);
      // الباك إند يرسل البيانات داخل حقل 'data'
      if (body is Map && body['data'] is List) {
        return body['data'];
      }
    }
  } catch (e) {
    debugPrint("❌ Maintenance Status API Error: $e");
  }
  return [];
}

// 2. تحديث تحديث العداد (Mileage) ليتوافق مع المسمى الجديد
Future<bool> updateCarMileage(String carId, int mileageKm) async {
  final token = await _getToken();
  try {
    final response = await http.patch(
      Uri.parse('$baseUrl/cars/$carId'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: json.encode({'mileageKm': mileageKm}), // استخدام المسمى الموحد
    );
    
    _checkUnauthorized(response);
    return response.statusCode == 200;
  } catch (e) {
    debugPrint("❌ Update Mileage API Error: $e");
    return false;
  }
}
// أضف هذه الدالة داخل CarService لو مش موجودة
Future<List<dynamic>> getServiceHistory(String carId) async {
  final token = await _getToken();
  try {
    final response = await http.get(
      Uri.parse('$baseUrl/maintenance/history/$carId'), // تأكد من صحة الـ Path في الباك إند
      headers: {'Authorization': 'Bearer $token'},
    );
    _checkUnauthorized(response); // ✅ أضف هذا السطر هنا
    if (response.statusCode == 200) {
      final body = json.decode(response.body);
      return body is Map ? (body['data'] ?? []) : body;
    }
  } catch (e) {
    debugPrint("❌ History API Error: $e");
  }
  return [];
}
  // 8. حذف سيارة
  Future<bool> deleteCar(String carId) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/cars/$carId'),
        headers: await _getHeaders(),
      );
      _checkUnauthorized(response); // ✅ أضف هذا السطر هنا
      return response.statusCode == 200 || response.statusCode == 204;
    } catch (e) {
      debugPrint("❌ Delete Car Error: $e");
      return false;
    }
  }
}