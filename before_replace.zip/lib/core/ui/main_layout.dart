import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';
import '../../screens/home_screen.dart';
import '../../screens/car_details_screen.dart';
import '../../screens/marketplace_screen.dart';
import '../../screens/emergency_screen.dart';
import '../../screens/more/more_screen.dart';
import '../constants/app_colors.dart';
import 'app_footer.dart';
import 'fade_indexed_stack.dart'; // ✅ استيراد الويدجت الجديد

class MainLayout extends StatelessWidget {
  const MainLayout({super.key});

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final int currentIndex = appProvider.currentTabIndex;

    final List<Widget> screens = [
      HomeScreen(onCarSelected: () => appProvider.setTabIndex(1)),
      const CarDetailsScreen(),
      const MarketplaceScreen(),
      const EmergencyScreen(),
      const MoreScreen(),
    ];

    return PopScope(
      canPop: currentIndex == 0,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        appProvider.setTabIndex(0);
      },
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light.copyWith(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
        ),
        child: Scaffold(
          extendBody: true,
          resizeToAvoidBottomInset: false, 
          
          // ✅ التعديل هنا: استخدام FadeIndexedStack بدلاً من AnimatedSwitcher
          body: FadeIndexedStack(
            index: currentIndex,
            children: screens,
          ),
          
          floatingActionButton: FloatingActionButton(
            onPressed: () => appProvider.setTabIndex(2),
            backgroundColor: AppColors.primary,
            elevation: 10,
            shape: const CircleBorder(),
            child: const Icon(Icons.storefront, color: Colors.black, size: 28),
          ),
          floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

          bottomNavigationBar: AppFooter(
            currentIndex: currentIndex,
            onTap: (index) => appProvider.setTabIndex(index),
          ),
        ),
      ),
    );
  }
}