import 'package:easy_localization/easy_localization.dart';
import 'package:elgarage/core/constants/app_colors.dart';
import 'package:elgarage/screens/add_car_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/car_card.dart';
import '../../core/ui/app_header.dart';
import '../../core/ui/textured_background.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback? onCarSelected;
  const HomeScreen({super.key, this.onCarSelected});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // ✅ نداء البيانات في الخلفية إذا كانت القائمة فارغة
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final app = Provider.of<AppProvider>(context, listen: false);
      if (app.myCars.isEmpty) {
        final role = Provider.of<AuthProvider>(context, listen: false).user?.role;
        app.fetchMyCars(role: role);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = Provider.of<AppProvider>(context);
final auth = Provider.of<AuthProvider>(context, listen: false);
app.fetchMyCars(role: auth.user?.role, authProvider: auth);
    bool isInitialLoading = app.isLoadingCars && app.myCars.isEmpty;

    return TexturedBackground(
      child: SafeArea(
        child: Column(
          children: [
            AppHeader(
              title: 'home.welcome',
              userName: auth.user?.name ?? 'User',
              statsText: '${app.myCars.length} ${'home.my_garage'.tr().toUpperCase()}',
              actionLabel: 'home.add_car_title',
              onActionPressed: () => Navigator.push(
                context, 
                MaterialPageRoute(builder: (_) => const AddCarScreen())
              ),
            ),
            
            Expanded(
              child: isInitialLoading 
                ? const Center(child: CircularProgressIndicator(color: Colors.amber))
                : RefreshIndicator( // ✅ إضافة ميزة السحب للتحديث
                    onRefresh: () async {
                      final role = Provider.of<AuthProvider>(context, listen: false).user?.role;
                      await app.fetchMyCars(role: role, forceRefresh: true);
                    },
                    color: Colors.amber,
                    child: app.myCars.isEmpty 
                      ? _buildEmptyState(context) // ✅ تمرير الـ context هنا
                      : ReorderableListView.builder(
                          padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
                          itemCount: app.myCars.length,
                          onReorder: (oldIndex, newIndex) {
                            app.reorderMyCars(oldIndex, newIndex);
                          },
                          itemBuilder: (context, index) {
                            final car = app.myCars[index];
                            return Container(
                              key: ValueKey(car.id), 
                              margin: const EdgeInsets.only(bottom: 12),
                              child: CarCard(
                                car: car,
                                isSelected: app.selectedCar?.id == car.id,
                                onTap: () {
                                  app.setSelectedCar(car);
                                  if (widget.onCarSelected != null) widget.onCarSelected!();
                                },
                              ),
                            );
                          },
                        ),
                  ),
            ),
          ],
        ),
      ),
    );
  }

  // ✅ تعديل الـ Empty State ليكون أكثر تفاعلية
  Widget _buildEmptyState(BuildContext context) {
    return SingleChildScrollView( // ضروري عشان الـ RefreshIndicator يشتغل
      physics: const AlwaysScrollableScrollPhysics(),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.6,
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.directions_car_outlined, size: 80, color: Colors.grey),
            const SizedBox(height: 15),
            Text(
              "home.empty_garage".tr(),
              style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, fontSize: 16)
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddCarScreen())),
              icon: const Icon(Icons.add),
              label: Text('home.add_car_title'.tr()),
              style: ElevatedButton.styleFrom(
                
                backgroundColor: AppColors.textMain.withAlpha(30),
                foregroundColor: AppColors.textMain,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))
              ),
            )
          ],
        ),
      ),
    );
  }
}