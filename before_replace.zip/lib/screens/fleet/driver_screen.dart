import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/ui/textured_background.dart';
import '../../providers/fleet_provider.dart';
import '../../providers/auth_provider.dart';
import '../car_details_screen.dart'; // افترضت وجودها في هذا المسار

class DriverScreen extends StatefulWidget {
  const DriverScreen({super.key});

  @override
  State<DriverScreen> createState() => _DriverScreenState();
}

class _DriverScreenState extends State<DriverScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _kmController = TextEditingController();
  final TextEditingController _litersController = TextEditingController();
  final TextEditingController _costController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    final fleet = Provider.of<FleetProvider>(context);
    final auth = Provider.of<AuthProvider>(context);

    return TexturedBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Column(
            children: [
              // 1. لوجو الجراج فقط في الأعلى
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 30),
                child: Image.asset('assets/images/logo_gold.png', height: 60), 
              ),

              // 2. كرت بيانات السيارة (لو تم عمل سكان)
              if (fleet.authenticatedCar != null)
                _buildVehicleInfo(fleet)
              else
                _buildScanPrompt(),

              const SizedBox(height: 20),

              // 3. التبويبات (Tabs)
              TabBar(
                controller: _tabController,
                indicatorColor: AppColors.primary,
                labelColor: AppColors.primary,
                unselectedLabelColor: Colors.white60,
                tabs: const [
                  Tab(text: "تسجيل وقود", icon: Icon(Icons.local_gas_station)),
                  Tab(text: "حالة الصيانة", icon: Icon(Icons.build)),
                ],
              ),

              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildFuelForm(fleet),
                    _buildMaintenanceStatus(fleet),
                  ],
                ),
              ),

              // 4. زر خروج (Logout) بسيط جداً في الأسفل
              TextButton.icon(
                onPressed: () => auth.logout(),
                icon: const Icon(Icons.logout, color: Colors.redAccent, size: 16),
                label: const Text("تسجيل خروج", style: TextStyle(color: Colors.redAccent, fontSize: 12)),
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVehicleInfo(FleetProvider fleet) {
    final car = fleet.authenticatedCar!;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: AppColors.cardColor.withOpacity(0.8),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: AppColors.primary.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.directions_car, color: AppColors.primary, size: 40),
          const SizedBox(width: 15),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("${car.make} ${car.model}", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              Text("لوحة: ${car.licensePlate}", style: const TextStyle(color: Colors.white70, fontSize: 12)),
              Text("العداد الحالي: ${car.mileageKm} كم", style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold)),
            ],
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () {
              // فتح صفحة التفاصيل (العرض فقط)
              Navigator.push(context, MaterialPageRoute(builder: (_) => const CarDetailsScreen()));
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.black),
            child: const Text("سيارتي"),
          )
        ],
      ),
    );
  }

  Widget _buildScanPrompt() {
    return const Center(
      child: Text("يرجى عمل Scan للباركود الموجود على السيارة", 
        style: TextStyle(color: Colors.white60, fontSize: 14)),
    );
  }

  Widget _buildFuelForm(FleetProvider fleet) {
    if (fleet.authenticatedCar == null) return const Center(child: Text("لا توجد سيارة محددة"));
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          _buildInput(_kmController, "قراءة العداد الحالية (كم)", Icons.speed),
          const SizedBox(height: 10),
          _buildInput(_litersController, "عدد اللترات", Icons.opacity),
          const SizedBox(height: 10),
          _buildInput(_costController, "التكلفة الإجمالية", Icons.payments),
          const SizedBox(height: 20),
          if (fleet.error != null)
            Text(fleet.error!, style: const TextStyle(color: Colors.red, fontSize: 12)),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: fleet.isLoading ? null : () async {
                final success = await fleet.submitFuelLog(
                  newOdometer: int.tryParse(_kmController.text) ?? 0,
                  liters: double.tryParse(_litersController.text) ?? 0,
                  cost: double.tryParse(_costController.text) ?? 0,
                  fuelType: "GASOLINE_95",
                );
                if (success) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("تم تسجيل البيانات بنجاح")));
                  _kmController.clear();
                  _litersController.clear();
                  _costController.clear();
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
              child: fleet.isLoading 
                ? const CircularProgressIndicator(color: Colors.black)
                : const Text("إرسال بيانات يوم العمل", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMaintenanceStatus(FleetProvider fleet) {
    // هنا يمكن استدعاء قائمة بسيطة توضح الصيانات المطلوبة
    return const Center(child: Text("سيتم عرض تنبيهات الصيانة هنا", style: TextStyle(color: Colors.white38)));
  }

  Widget _buildInput(TextEditingController controller, String label, IconData icon) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white60, fontSize: 12),
        prefixIcon: Icon(icon, color: AppColors.primary, size: 20),
        filled: true,
        fillColor: Colors.white10,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      ),
    );
  }
}