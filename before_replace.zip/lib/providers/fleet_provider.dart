import 'package:elgarage/core/services/api_service.dart';
import 'package:flutter/material.dart';
import '../core/models/car_model.dart';

class FleetProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();

  bool _isLoading = false;
  String? _error;
  Car? _authenticatedCar; // السيارة التي تم عمل سكان لها
  Map<String, dynamic>? _fleetStats;

  bool get isLoading => _isLoading;
  String? get error => _error;
  Car? get authenticatedCar => _authenticatedCar;
  Map<String, dynamic>? get fleetStats => _fleetStats;

  // التحقق من الباركود وجلب بيانات السيارة
  Future<bool> verifyVehicle(String barcode) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final data = await _apiService.verifyBarcode(barcode);
      // تحويل البيانات لـ Car Model (بناءً على الـ JSON الراجع من الباك إند)
      _authenticatedCar = Car.fromJson(data);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // تسجيل الوقود مع التحقق من العداد (Odometer Validation)
  Future<bool> submitFuelLog({
    required int newOdometer,
    required double liters,
    required double cost,
    required String fuelType,
  }) async {
    if (_authenticatedCar == null) return false;

    // 🛑 منطق منع الخطأ: العداد الجديد لا يمكن أن يكون أقل من الحالي
    if (newOdometer <= _authenticatedCar!.mileageKm) {
      _error = "العداد المدخل أقل من أو يساوي العداد الحالي (${_authenticatedCar!.mileageKm})";
      notifyListeners();
      return false;
    }

    _isLoading = true;
    notifyListeners();

    try {
      await _apiService.addFuelLog({
        "carId": _authenticatedCar!.id,
        "odometerKms": newOdometer,
        "fuelType": fuelType,
        "liters": liters,
        "totalCost": cost,
      });
      
      // تحديث العداد محلياً بعد النجاح
      _authenticatedCar = _authenticatedCar!.copyWith(mileageKm: newOdometer);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> loadFleetStats() async {
    try {
      _fleetStats = await _apiService.getFleetDashboard();
      notifyListeners();
    } catch (e) {
      debugPrint("Stats Error: $e");
    }
  }
}