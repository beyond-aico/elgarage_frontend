import 'package:elgarage/core/services/car_service.dart';
import 'package:elgarage/providers/auth_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart'; // ✅ إضافة Material للـ Colors
import '../core/models/car_model.dart';
import '../core/models/product_model.dart';
import '../core/models/emergency_model.dart';

class AppProvider with ChangeNotifier {
  final CarService _carService = CarService();

  // --- إدارة السيارات (البيانات الأساسية) ---
  List<Car> _myCars = [];
  Car? _selectedCar;
  bool _isLoadingCars = false;
  String? _carError;
  bool _isUpdatingMileage = false;

  List<Car> get myCars => _myCars;
  Car? get selectedCar => _selectedCar;
  bool get isLoadingCars => _isLoadingCars;
  String? get carError => _carError;
  bool get isUpdatingMileage => _isUpdatingMileage;

  // --- إدارة المتجر والطلبات ---
  final List<ProductModel> _cartItems = [];
  final List<Map<String, dynamic>> _myOrders = []; 
  List<ProductModel> get cartItems => _cartItems;
  List<Map<String, dynamic>> get myOrders => _myOrders;
  double get cartTotal => _cartItems.fold(0, (sum, item) => sum + item.price);

  // --- بيانات المؤسسة والواجهة ---
  String? _organizationName;
  String get organizationName => _organizationName ?? "Personal Garage";
  int _currentTabIndex = 0;
  int get currentTabIndex => _currentTabIndex;

  // --- مزامنة السياق ---
  Future<void> syncUserContext(dynamic user) async {
    if (user == null) return;
    _organizationName = user.organizationName;
    await fetchMyCars(role: user.role, forceRefresh: true);
  }

  // ✅ إصلاح دالة تحليل الأسطول (تم إزالة الاعتماد على carHealthScore المفقود)
  Map<String, dynamic> get fleetAnalytics {
    if (_myCars.isEmpty) {
      return {
        "total_units": 0,
        "maintenance_due": 0,
        "efficiency": "0%",
      };
    }

    int total = _myCars.length;
    // ملاحظة: حساب الـ maintenance_due للأسطول يحتاج الآن لطلب منفصل أو تعديل في الباك إند
    // سنضعها 0 مؤقتاً لضمان عدم توقف التطبيق عن العمل
    return {
      "total_units": total,
      "active_now": total,
      "maintenance_due": 0, 
      "monthly_cost": "--- EGP",
      "efficiency": "100%",
    };
  }

  // ✅ إعادة دالة ترتيب السيارات (مطلوبة لشاشة HomeScreen)
  void reorderMyCars(int oldIndex, int newIndex) {
    if (newIndex > oldIndex) newIndex -= 1;
    final item = _myCars.removeAt(oldIndex);
    _myCars.insert(newIndex, item);
    notifyListeners();
  }

  // ✅ قائمة مراكز الخدمة (مطلوبة لشاشة CartScreen)
  final List<Map<String, dynamic>> _serviceCenters = [
    {'name': 'Auto Fix Center', 'location': 'Nasr City', 'labor_cost': 200.0},
    {'name': 'Pro Car Service', 'location': 'New Cairo', 'labor_cost': 300.0},
  ];
  List<Map<String, dynamic>> get serviceCenters => _serviceCenters;

  // ✅ دالة الصور (مطلوبة لعرض القطع في السلة)
  String getImageForPart(String partName) {
    String name = partName.toLowerCase();
    if (name.contains('oil')) return 'assets/images/engine_oil.png';
    if (name.contains('spark')) return 'assets/images/spark_plug.png';
    if (name.contains('brake')) return 'assets/images/brake_pad.png';
    return 'assets/images/engine_oil.png';
  }

  // --- إدارة السيارات (Actions) ---
  Future<void> fetchMyCars({
    String? role,
    AuthProvider? authProvider,
    bool forceRefresh = false,
  }) async {
    if (_isLoadingCars && !forceRefresh) return;
    _isLoadingCars = true;
    _carError = null;
    Future.microtask(() => notifyListeners());

    try {
      List<Car> fetchedCars = (role == "ACCOUNT_MANAGER" || role == "ADMIN")
          ? await _carService.getFleetCars()
          : await _carService.getMyCars();

      _myCars = fetchedCars;

      if (_myCars.isNotEmpty) {
        if (_selectedCar == null) {
          _selectedCar = _myCars.first;
        } else {
          int index = _myCars.indexWhere((c) => c.id == _selectedCar!.id);
          _selectedCar = (index != -1) ? _myCars[index] : _myCars.first;
        }
      }
    } catch (e) {
      if (e.toString().contains('UNAUTHORIZED')) {
        authProvider?.handleUnauthorized();
      } else {
        _carError = e.toString();
      }
    } finally {
      _isLoadingCars = false;
      notifyListeners();
    }
  }

  void setSelectedCar(Car car) {
    _selectedCar = car;
    notifyListeners();
  }

  Future<bool> addNewCarv2(Map<String, dynamic> carData) async {
    try {
      await _carService.addCar(carData); 
      await fetchMyCars();
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> removeCar(String carId) async {
    try {
      await _carService.deleteCar(carId);
      _myCars.removeWhere((c) => c.id == carId);
      if (_selectedCar?.id == carId) _selectedCar = null;
      notifyListeners();
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> updateCarCurrentKm(int newKm) async {
    if (_selectedCar == null) return false;
    _isUpdatingMileage = true;
    notifyListeners();
    try {
      bool success = await _carService.updateCarMileage(_selectedCar!.id, newKm);
      if (success) {
        _selectedCar = _selectedCar!.copyWith(currentKm: newKm);
        int index = _myCars.indexWhere((c) => c.id == _selectedCar!.id);
        if (index != -1) _myCars[index] = _selectedCar!;
        return true;
      }
      return false;
    } finally {
      _isUpdatingMileage = false;
      notifyListeners();
    }
  }

  // --- إدارة المتجر (Actions) ---
  void addToCart(List<dynamic> items) {
    for (var item in items) {
      if (item is ProductModel) {
        if (!_cartItems.any((e) => e.name == item.name)) {
          _cartItems.add(item);
        }
      }
    }
    notifyListeners();
  }

  void removeFromCart(dynamic item) {
    _cartItems.remove(item);
    notifyListeners();
  }

  void placeOrder() {
    if (_cartItems.isEmpty) return;
    _myOrders.insert(0, {
      'id': 'ORD-${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}',
      'date': DateTime.now(),
      'items': List.from(_cartItems),
      'total': cartTotal,
      'status': 'Pending'
    });
    _cartItems.clear();
    notifyListeners();
  }

  // --- بيانات ثابتة (Market & Emergency) ---
  final List<ProductModel> _marketProducts = [
    ProductModel(id: 'p1', name: 'Total Quartz 9000 5W-40', price: 1450, category: 'Oils', imagePath: 'assets/images/1.jpg'),
    ProductModel(id: 'p2', name: 'Brembo Brake Pads Set', price: 2800, category: 'Brakes', imagePath: 'assets/images/2.png'),
    ProductModel(id: 'p3', name: 'NGK Iridium Spark Plugs', price: 1100, category: 'Engine', imagePath: 'assets/images/3.jfif'),
    ProductModel(id: 'p4', name: 'Bosch Premium Oil Filter', price: 450, category: 'Filters', imagePath: 'assets/images/1.jpg'),
  ];
  List<ProductModel> get marketProducts => _marketProducts;

  final List<EmergencyModel> _emergencyContacts = [
    EmergencyModel(name: 'Helpoo Roadside Assistance', phoneNumber: '17000', location: 'All Egypt', type: 'Winch', rating: '5.0'),
    EmergencyModel(name: 'Battery Express', phoneNumber: '19110', location: 'Greater Cairo', type: 'Battery', rating: '4.9'),
  ];
  List<EmergencyModel> getEmergencyByType(String type) => 
      _emergencyContacts.where((e) => e.type == type).toList();

  final List<Map<String, dynamic>> _categories = [
    {'name': 'All', 'icon': CupertinoIcons.square_grid_2x2_fill},
    {'name': 'Service Centers', 'icon': CupertinoIcons.wrench_fill},
    {'name': 'Oils', 'icon': CupertinoIcons.drop_fill},
  ];
  List<Map<String, dynamic>> get categories => _categories;

  void setTabIndex(int index) {
    _currentTabIndex = index;
    notifyListeners();
  }

  // --- جلب البيانات المرجعية ---
  Future<List<dynamic>> fetchBrands() async => await _carService.getBrands();
  Future<List<dynamic>> fetchModels(String brandId) async => await _carService.getModels(brandId);

  void clearData() {
    _myCars = [];
    _selectedCar = null;
    _organizationName = null;
    _carError = null;
    notifyListeners();
  }

void resetOnLogout() {
    _currentTabIndex = 0;
    _selectedCar = null;
    _myCars = [];
    _organizationName = null;
    _cartItems.clear(); // تنظيف السلة
    _myOrders.clear();  // تنظيف الطلبات المحلية
    _carError = null;
    notifyListeners();
  }

  void fetchDueMaintenance({required String carId}) {}
}