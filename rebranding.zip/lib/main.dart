import 'package:elgarage/screens/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'core/constants/app_colors.dart';
import 'providers/app_provider.dart';
import 'providers/auth_provider.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const ElGarageApp());
}

class ElGarageApp extends StatelessWidget {
  const ElGarageApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
      ],
      child: MaterialApp(
        title: 'El Garage',
        debugShowCheckedModeBanner: false,
        themeMode: ThemeMode.light, // لايت مود إجباري
        
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.light,
          primaryColor: AppColors.primary,
          scaffoldBackgroundColor: AppColors.background,
          
          // خطوط عريضة وحادة (Industrial Typography)
          textTheme: GoogleFonts.cairoTextTheme(ThemeData.light().textTheme).copyWith(
            displayLarge: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.textPrimary, letterSpacing: -1),
            headlineMedium: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            titleLarge: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
            bodyLarge: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.textPrimary),
          ),
          
          colorScheme: const ColorScheme.light(
            primary: AppColors.primary,
            secondary: AppColors.accent,
            surface: AppColors.surface,
            onPrimary: Colors.white,
          ),

          // أزرار حادة وقوية
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              elevation: 0, // فلات (Flat)
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8), // زوايا شبه حادة
                side: const BorderSide(color: Colors.black12, width: 1), // إطار خفيف
              ),
              padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 24),
              textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
            ),
          ),
          
          // كروت بستايل "اللوحات المعدنية"
          cardTheme: CardThemeData(
            color: AppColors.surface,
            elevation: 5,
            shadowColor: Colors.black.withValues(alpha: 0.2),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.black.withValues(alpha: 0.05), width: 1),
            ),
          ),

          // انتقالات سريعة وميكانيكية
          pageTransitionsTheme: const PageTransitionsTheme(
            builders: {
              TargetPlatform.android: ZoomPageTransitionsBuilder(),
              TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
            },
          ),
        ),
        
        home: const LoginScreen(),
      ),
    );
  }
}