import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class ConstructionStripes extends StatelessWidget {
  final double opacity;
  
  const ConstructionStripes({super.key, this.opacity = 0.05});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: CustomPaint(
        painter: _StripesPainter(color: AppColors.stripesColor.withValues(alpha: opacity)),
        child: Container(),
      ),
    );
  }
}

class _StripesPainter extends CustomPainter {
  final Color color;
  _StripesPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 10 // سمك الخط
      ..style = PaintingStyle.stroke;

    // رسم خطوط مائلة كل 20 بيكسل
    for (double i = -size.height; i < size.width; i += 25) {
      canvas.drawLine(
        Offset(i, size.height),
        Offset(i + size.height, 0),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}