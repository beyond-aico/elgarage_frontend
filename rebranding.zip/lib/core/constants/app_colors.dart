import 'package:flutter/material.dart';

class AppColors {
  // === لون الهوية (برتقالي الإنشاءات الغامق) ===
  static const Color primary = Color(0xFFE65100); // برتقالي غامق وقوي (Safety Orange)
  static const Color primaryDark = Color.fromARGB(255, 116, 75, 6); // درجة الطوب المحروق
  static const Color accent = Color(0xFF212121); // أسود كربوني للتطعيمات

  // === الخلفيات (أسمنتي فاتح) ===
  static const Color background = Color(0xFFF5F5F5); // رمادي فاتح (Concrete)
  static const Color surface = Color(0xFFFFFFFF); // أبيض صريح
  
  // ✅ تم تعريف اللون الناقص هنا
  static const Color surfaceLight = Color(0xFFFAFAFA); // أبيض مائل للرمادي خفيف جداً

  // === النصوص (High Contrast) ===
  static const Color textPrimary = Color(0xFF212121); // أسود صريح
  static const Color textSecondary = Color(0xFF757575); // رمادي معدني
  static const Color textInverse = Color(0xFFFFFFFF); 

  // === عناصر مساعدة (للخطوط المائلة) ===
  static const Color stripesColor = Color(0xFF212121); // لون الخطوط المائلة (أسود)
  
  // === التوافق مع الكود القديم ===
  static const Color success = Color(0xFF2E7D32);
  static const Color warning = Color(0xFFF9A825);
  static const Color error = Color.fromARGB(255, 233, 184, 38);
  static const Color cardColor = surface;
  static const Color secondary = accent;
  static const Color iconColor = textPrimary;
}