import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_colors.dart';
import '../core/ui/construction_stripes.dart'; // استيراد الودجت الجديدة
import '../providers/app_provider.dart';
import '../providers/auth_provider.dart';
import '../widgets/car_card.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, this.onCarSelected});
  final VoidCallback? onCarSelected;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animController;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AppProvider>(context, listen: false).fetchMyCars();
    });
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final appProvider = Provider.of<AppProvider>(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            // ==========================================
            // 1. الهيدر الصناعي (Industrial Header)
            // ==========================================
            Container(
              height: 200,
              width: double.infinity,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(0)), // حواف حادة
                border: Border(bottom: BorderSide(color: AppColors.primary, width: 4)), // خط برتقالي سميك تحت
              ),
              child: Stack(
                children: [
                  // أ. الخلفية المنقرشة (الخطوط المائلة)
                  const Positioned.fill(
                    child: ConstructionStripes(opacity: 0.03), // خطوط خفيفة جداً في الخلفية
                  ),

                  // ب. المحتوى
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // الصف العلوي: اللوجو والبروفايل
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // زرار البروفايل (شكله زي الصامولة/Truss)
                            GestureDetector(
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen())),
                              child: Container(
                                padding: const EdgeInsets.all(2),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.black, width: 2), // إطار أسود
                                ),
                                child: const CircleAvatar(
                                  radius: 20,
                                  backgroundColor: AppColors.background,
                                  child: Icon(Icons.person, color: Colors.black),
                                ),
                              ),
                            ),
                            
                            // اللوجو (صورة)
                            Image.asset('assets/images/logo.png', height: 40),
                          ],
                        ),
                        
                        const Spacer(),

                        // الترحيب (بفونت عريض)
                        FadeTransition(
                          opacity: _animController,
                          child: const Text(
                            "WELCOME BACK,",
                            style: TextStyle(
                              color: Colors.grey, 
                              fontSize: 14, 
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2
                            ),
                          ),
                        ),
                        SlideTransition(
                          position: Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(_animController),
                          child: RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: authProvider.user?.name ?? "DRIVER",
                                  style: const TextStyle(
                                    color: Colors.black, // الاسم بالأسود
                                    fontSize: 32,
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.w900,
                                    height: 1.1,
                                  ),
                                ),
                                const TextSpan(text: "\n"),
                                const TextSpan(
                                  text: "EL GARAGE", // كلمة الجراج
                                  style: TextStyle(
                                    color: AppColors.primary, // بالبرتقالي الغامق
                                    fontSize: 32,
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.w900,
                                    height: 1.1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // ج. زخرفة الخطوط المائلة القوية (على اليمين فوق)
                  Positioned(
                    top: 0,
                    right: 0,
                    width: 80,
                    height: 80,
                    child: ClipRect(
                      child: CustomPaint(
                        painter: _CornerStripesPainter(),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ==========================================
            // 2. المحتوى (القائمة)
            // ==========================================
            Expanded(
              child: RefreshIndicator(
                onRefresh: () async => await appProvider.fetchMyCars(),
                color: AppColors.primary,
                child: CustomScrollView(
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(24, 25, 24, 15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.black,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text(
                                "YOUR FLEET", // كلمة Fleet بدل Garage لتناسب الروح الصناعية
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.0,
                                ),
                              ),
                            ),
                            
                            // زرار إضافة "خشن"
                            InkWell(
                              onTap: () {},
                              child: Row(
                                children: const [
                                  Icon(Icons.add_box, color: AppColors.primary, size: 20),
                                  SizedBox(width: 4),
                                  Text("ADD VEHICLE", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),

                    Builder(
                      builder: (context) {
                        if (appProvider.isLoadingCars) {
                          return const SliverFillRemaining(
                            child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
                          );
                        }

                        if (appProvider.myCars.isEmpty) {
                          return const SliverFillRemaining(
                            child: Center(child: Text("NO VEHICLES FOUND", style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold))),
                          );
                        }

                        return SliverPadding(
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          sliver: SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (context, index) {
                                final car = appProvider.myCars[index];
                                return AnimatedBuilder(
                                  animation: _animController,
                                  builder: (context, child) {
                                    final double slide = 50.0 * (1.0 - _animController.value) * (index + 1);
                                    return Transform.translate(
                                      offset: Offset(0, slide),
                                      child: Opacity(
                                        opacity: _animController.value,
                                        child: child,
                                      ),
                                    );
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(bottom: 16),
                                    child: GestureDetector(
                                      onTap: () async {
                                        appProvider.setSelectedCar(car);
                                        await appProvider.fetchDueMaintenance(carId: car.id);
                                        if (widget.onCarSelected != null) widget.onCarSelected!();
                                      },
                                      child: Hero(
                                        tag: 'car_hero_${car.id}',
                                        child: CarCard(car: car),
                                      ),
                                    ),
                                  ),
                                );
                              },
                              childCount: appProvider.myCars.length,
                            ),
                          ),
                        );
                      },
                    ),
                    const SliverToBoxAdapter(child: SizedBox(height: 100)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// رسمة الزاوية (الخطوط السوداء المائلة القوية) زي اللوجو
class _CornerStripesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black
      ..strokeWidth = 6
      ..style = PaintingStyle.stroke;

    // رسم 3 خطوط مائلة في الزاوية
    canvas.drawLine(const Offset(40, 0), const Offset(80, 40), paint);
    canvas.drawLine(const Offset(20, 0), const Offset(80, 60), paint);
    canvas.drawLine(const Offset(0, 0), const Offset(80, 80), paint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}