import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_colors.dart';
import '../providers/app_provider.dart';
import 'tabs/emergency_tab.dart';
import 'tabs/history_tab.dart';
import 'tabs/maintenance_tab.dart';

class CarDetailsScreen extends StatefulWidget {
  const CarDetailsScreen({super.key});

  @override
  State<CarDetailsScreen> createState() => _CarDetailsScreenState();
}

class _CarDetailsScreenState extends State<CarDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, provider, child) {
        final selectedCar = provider.selectedCar;

        // حالة عدم اختيار سيارة (حماية)
        if (selectedCar == null) {
          return const Scaffold(
            backgroundColor: AppColors.background,
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.directions_car_outlined, size: 80, color: Colors.grey),
                  SizedBox(height: 20),
                  Text("Please select a car from Home first", style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
          );
        }

        return DefaultTabController(
          length: 3,
          initialIndex: 1, // يبدأ على تبويب الصيانة
          child: Scaffold(
            backgroundColor: AppColors.background,
            body: Column(
              children: [
                // ==========================================
                // 1. الهيدر الاحترافي (Hero + Gradient + Data)
                // ==========================================
                Stack(
                  children: [
                    // أ. خلفية الصورة مع أنيميشن الهيرو
                    Hero(
                      tag: 'car_hero_${selectedCar.id}', // لازم نفس التاج اللي في الهوم
                      child: Container(
                        height: 300, // ارتفاع كبير للصورة
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: AppColors.primary, // لون احتياطي
                          image: selectedCar.imageUrl != null
                              ? DecorationImage(
                                  image: NetworkImage(selectedCar.imageUrl!),
                                  fit: BoxFit.cover,
                                )
                              : null,
                        ),
                        // أيقونة احتياطية لو مفيش صورة
                        child: selectedCar.imageUrl == null
                            ? Icon(Icons.directions_car, size: 120, color: Colors.white.withAlpha(2))
                            : null,
                      ),
                    ),

                    // ب. طبقة تظليل (Gradient) عشان الكلام يبان
                    Container(
                      height: 300,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withAlpha(1), // شفاف فوق
                            Colors.black.withAlpha(8), // غامق تحت
                          ],
                        ),
                      ),
                    ),

                    // ج. زر الرجوع
                    Positioned(
                      top: 40, // عشان ينزل تحت الـ Status Bar
                      left: 10,
                      child: IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ),

                    // د. بيانات السيارة (Sync حقيقي)
                    Positioned(
                      bottom: 40, // نرفعها شوية عشان التابات
                      left: 20,
                      right: 20,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // الماركة والموديل
                          Text(
                            "${selectedCar.make} ${selectedCar.model}",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.1,
                              shadows: [Shadow(blurRadius: 10, color: Colors.black)],
                            ),
                          ),
                          const SizedBox(height: 8),
                          
                          // التفاصيل (سنة - لون - عداد)
                          Row(
                            children: [
                              _buildInfoChip(Icons.calendar_today, "${selectedCar.year}"),
                              const SizedBox(width: 10),
                              _buildInfoChip(Icons.palette, selectedCar.color ?? "Unknown"),
                              const Spacer(),
                              // عداد الكيلومترات بشكل مميز
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: AppColors.primary,
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 8)],
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.speed, color: Colors.white, size: 18),
                                    const SizedBox(width: 5),
                                    Text(
                                      "${selectedCar.currentKm} KM",
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                // ==========================================
                // 2. التابات (Tabs) مع تداخل جمالي
                // ==========================================
                Transform.translate(
                  offset: const Offset(0, -20), // ترفع التابات لفوق شوية لتتداخل مع الهيدر
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withAlpha(1),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: TabBar(
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicator: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      labelColor: Colors.white,
                      unselectedLabelColor: AppColors.textSecondary,
                      labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      tabs: const [
                        Tab(text: 'History'),
                        Tab(text: 'Maintenance'),
                        Tab(text: 'Emergency'),
                      ],
                    ),
                  ),
                ),

                // ==========================================
                // 3. محتوى الصفحات
                // ==========================================
                const Expanded(
                  child: TabBarView(
                    physics: BouncingScrollPhysics(), // حركة مرنة (Elastic Scroll)
                    children: [
                      HistoryTab(),
                      MaintenanceTab(),
                      EmergencyTab(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ودجت مساعدة صغيرة لشكل المعلومات
  Widget _buildInfoChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(2),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white70, size: 14),
          const SizedBox(width: 4),
          Text(
            label,
            style: const TextStyle(color: Colors.white, fontSize: 12),
          ),
        ],
      ),
    );
  }
}