import 'package:flutter/material.dart';
import '../core/constants/app_colors.dart';
import '../core/ui/construction_stripes.dart';
import '../data/models/car_model.dart';

class CarCard extends StatelessWidget {
  final Car car;
  const CarCard({super.key, required this.car});

  @override
  Widget build(BuildContext context) {
    final bool hasImage = car.imageUrl != null && car.imageUrl!.isNotEmpty;

    return Container(
      height: 200,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12), // حواف أقل دائرية (أكثر حدة)
        border: Border.all(color: Colors.grey[300]!, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          )
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(11),
        child: Stack(
          children: [
            // 1. الصورة
            Positioned.fill(
              child: hasImage
                  ? Image.network(
                      car.imageUrl!,
                      fit: BoxFit.cover,
                      errorBuilder: (_,__,___) => _buildPlaceholder(),
                    )
                  : _buildPlaceholder(),
            ),

            // 2. شريط المعلومات الجانبي (ستايل صناعي)
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              width: 60, // شريط عمودي
              child: Container(
                color: AppColors.primary, // الشريط البرتقالي
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // زخرفة خطوط سوداء
                    const SizedBox(
                      height: 50,
                      width: 60,
                      child: ConstructionStripes(opacity: 0.2),
                    ),
                    const Spacer(),
                    RotatedBox(
                      quarterTurns: 3,
                      child: Text(
                        "${car.year}",
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 18,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    const Spacer(),
                  ],
                ),
              ),
            ),

            // 3. المعلومات في الأسفل (على خلفية بيضاء)
            Positioned(
              bottom: 16,
              left: 76, // بعد الشريط البرتقالي
              right: 16,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.95),
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 5)],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          car.make.toUpperCase(),
                          style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.grey),
                        ),
                        Text(
                          car.model.toUpperCase(),
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Colors.black),
                        ),
                      ],
                    ),
                    
                    // الكيلومتر
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        "${car.currentKm} KM",
                        style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold, fontSize: 12),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Container(
      color: Colors.grey[200],
      child: const Center(
        child: Icon(Icons.directions_car, size: 60, color: Colors.grey),
      ),
    );
  }
}