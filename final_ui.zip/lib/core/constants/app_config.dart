class AppConfig {
  static const String serverIp = '192.168.8.17'; // العنوان الرئيسي
  static const String baseUrl = 'http://$serverIp:3000/api/v1';

  // النهايات (Endpoints)
  static const String auth = '$baseUrl/auth';
  static const String cars = '$baseUrl/cars';
  static const String maintenance = '$baseUrl/maintenance';
  static const String inventory = '$baseUrl/inventory'; // للماركت مستقبلاً

  static const String appName = 'El Garage';
  static const String appVersion = '2.0.5';
}