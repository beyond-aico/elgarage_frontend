import 'package:elgarage/core/ui/app_footer.dart';
import 'package:elgarage/screens/marketplace_screen.dart';
import 'package:elgarage/screens/more_screen.dart';
import 'package:elgarage/screens/emergency_screen.dart'; 
import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../../screens/home_screen.dart';
import '../../screens/car_details_screen.dart';

class MainLayout extends StatefulWidget {
  const MainLayout({super.key});

  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  int _currentIndex = 0;

  void _switchToTab(int index) {
    setState(() => _currentIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> screens = [
      HomeScreen(onCarSelected: () => _switchToTab(1)), // 0: الجراج
      const CarDetailsScreen(), // 1: التفاصيل
      const MarketplaceScreen(), // 2: الماركت
      const EmergencyScreen(), // 3: السلة
      const MoreScreen(), // 4: المزيد
    ];

    // ✅ استخدام PopScope للتحكم في زر الرجوع
    return PopScope(
      canPop: _currentIndex == 0, // يسمح بالخروج فقط لو واقفين في الهوم
      onPopInvoked: (didPop) {
        if (didPop) return;
        // لو مش في الهوم، يرجعه للهوم (Tab 0)
        _switchToTab(0);
      },
      child: Scaffold(
        extendBody: true,
        body: IndexedStack(
          index: _currentIndex,
          children: screens,
        ),
      
      // زر الماركت بليس في المنتصف (FAB) - ستايل ثابت
      floatingActionButton: FloatingActionButton(
        onPressed: () => _switchToTab(2),
        backgroundColor: AppColors.primary,
        elevation: 10,
        shape: const CircleBorder(), 
        child: const Icon(Icons.storefront, color: Colors.black, size: 28),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

      // ✅ استدعاء الفوتر الموحد الذي يحتوي على الـ BottomAppBar والـ Notch
      bottomNavigationBar: AppFooter(
        currentIndex: _currentIndex,
        onTap: _switchToTab,
      ),
      )
    );
    
  }
}