// --- FILE: lib/core/ui/home_header.dart ---
import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class AppHeader extends StatelessWidget {
  final String title;
  final String userName; 
  final String statsText; // النص الذي يوضح عدد السيارات
  final String actionLabel;
  final VoidCallback onActionPressed;
  final IconData actionIcon;

  const AppHeader({
    super.key,
    required this.title,
    required this.userName,
    required this.statsText,
    required this.actionLabel,
    required this.onActionPressed,
    this.actionIcon = Icons.add_circle_outline,
  });

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double headerHeight = screenWidth * 0.38; 

    return Stack(
      children: [
        ClipPath(
          clipper: AdvancedWaveClipper(),
          child: Container(
            height: headerHeight,
            width: double.infinity,
            color: AppColors.textMain,
          ),
        ),
        Positioned(
          top: 0,
          right: 0,
          child: Image.asset(
            'assets/images/logo.png',
            width: screenWidth * 0.25, 
            fit: BoxFit.contain,
            errorBuilder: (context, error, stackTrace) =>
                const Padding(
                  padding: EdgeInsets.all(15.0),
                  child: Icon(Icons.garage_rounded, color: Colors.white12, size: 40),
                ),
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.06, vertical: 10),
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: TextStyle(color: Colors.white70, fontSize: screenWidth * 0.035)),
                    Text(userName, style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.06, fontWeight: FontWeight.w900, letterSpacing: 0.5)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.stars, color: AppColors.primary, size: 16),
                        const SizedBox(width: 5),
                        Text(statsText, style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: headerHeight * 0.18), 
                Center(
                  child: GestureDetector(
                    onTap: onActionPressed,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 12),
                      decoration: BoxDecoration(
                        color: AppColors.primary, 
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: AppColors.textMain, width: 2),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(actionIcon, color: AppColors.textMain, size: 20),
                          const SizedBox(width: 10),
                          Text(actionLabel.toUpperCase(), style: const TextStyle(color: AppColors.textMain, fontWeight: FontWeight.w900, letterSpacing: 1.2, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class AdvancedWaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, size.height - 50); 
    path.quadraticBezierTo(size.width / 2, size.height, size.width, size.height - 50);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }
  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}