// --- FILE: lib/main.dart ---

import 'package:elgarage/screens/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'core/constants/app_colors.dart';
import 'providers/app_provider.dart';
import 'providers/auth_provider.dart';
import 'core/ui/main_layout.dart'; 
import 'screens/fleet/fleet_dashboard.dart'; 
import 'screens/driver/driver_screen.dart'; 

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const AutoMentorApp());
}

class AutoMentorApp extends StatelessWidget {
  const AutoMentorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => AppProvider()),
      ],
      child: MaterialApp(
        title: 'Auto Mentor Fleet',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primaryColor: AppColors.primary,
          scaffoldBackgroundColor: AppColors.background,
          fontFamily: 'Roboto', 
          colorScheme: const ColorScheme.light(
            primary: AppColors.primary,
            secondary: AppColors.warning,
            surface: AppColors.cardColor,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              elevation: 4,
              shadowColor: Colors.black,
              shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
          useMaterial3: true,
        ),
        // ✅ إضافة الـ Builder لحماية التصميم من تكبير الخطوط المفاجئ
        builder: (context, child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(
              textScaler: TextScaler.linear(MediaQuery.of(context).textScaleFactor.clamp(1.0, 1.2)),
            ),
            child: child!,
          );
        },
        home: const InitialRouter(), 
      ),
    );
  }
}

// ✅ تحويل الـ InitialRouter ليكون StatefulWidget لفحص الـ Session
class InitialRouter extends StatefulWidget {
  const InitialRouter({super.key});

  @override
  State<InitialRouter> createState() => _InitialRouterState();
}

class _InitialRouterState extends State<InitialRouter> {
  @override
  void initState() {
    super.initState();
    // ✅ تشغيل محاولة الدخول التلقائي فور تشغيل التطبيق
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AuthProvider>(context, listen: false).tryAutoLogin();
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);

    // 1. أثناء فحص التوكن المخزن، اظهر مؤشر انتظار
    if (auth.isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    // 2. إذا لم يكن مسجلاً، اذهب للوج إن
    if (!auth.isAuthenticated) {
      return const LoginScreen();
    }

    // 3. التوجيه الذكي بناءً على الدور (Role) [cite: 56-62]
    final role = auth.user?.role;
    print("🚦 Current User Role: $role");

    if (role == "FLEET_MANAGER") {
      return const FleetDashboard(); 
    } else if (role == "DRIVER") {
      return const DriverScreen(); 
    } else {
      return const MainLayout(); 
    }
  }
}