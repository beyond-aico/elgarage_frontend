import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_colors.dart';
import '../providers/app_provider.dart';
import '../core/ui/textured_background.dart';
import 'tabs/history_tab.dart';
import 'tabs/maintenance_tab.dart';

class CarDetailsScreen extends StatefulWidget {
  const CarDetailsScreen({super.key});

  @override
  State<CarDetailsScreen> createState() => _CarDetailsScreenState();
}

class _CarDetailsScreenState extends State<CarDetailsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    // ✅ الحفاظ على تابتين فقط (History & Maintenance)
    _tabController = TabController(length: 2, vsync: this, initialIndex: 1);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, provider, child) {
        final selectedCar = provider.selectedCar;

        if (selectedCar == null) {
          return const Scaffold(
            backgroundColor: AppColors.background,
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(CupertinoIcons.car_detailed, size: 80, color: Colors.grey),
                  SizedBox(height: 20),
                  Text("Please select a car from Home first", style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
          );
        }

        return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: const BackButton(color: AppColors.textMain),
            actions: [
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.settings_outlined, color: AppColors.textMain),
              )
            ],
          ),
          body: TexturedBackground(
            child: Column(
              children: [
                const SizedBox(height: 60), 

                // ✅ تعديل رقم 1: تكبير الدائرة وجعل الصورة تغطيها بالكامل (Fit Cover)
                Hero(
                  tag: 'brand_logo_${selectedCar.id}',
                  child: Container(
                    height: 110, // زيادة الحجم قليلاً
                    width: 110,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 15,
                          offset: const Offset(0, 8),
                        )
                      ],
                      border: Border.all(color: AppColors.primary.withOpacity(0.5), width: 3),
                    ),
                    child: ClipOval( // استخدام ClipOval لضمان قص الصورة بشكل دائري دقيق
                      child: Image.asset(
                        'assets/images/car_logo.png',
                        fit: BoxFit.cover, // الصورة تملأ الدائرة بالكامل
                        errorBuilder: (c, e, s) => const Icon(Icons.directions_car, size: 50, color: AppColors.textMain),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 12),
                Text(
                  '${selectedCar.make} ${selectedCar.model}'.toUpperCase(),
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 0.8),
                ),
                Text(
                  selectedCar.licensePlate ?? 'No Plate',
                  style: const TextStyle(fontSize: 14, color: AppColors.textSub, fontWeight: FontWeight.bold, letterSpacing: 1),
                ),

                const SizedBox(height: 20),

                // شريط الحالة (Stats Strip)
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  decoration: BoxDecoration(
                    color: AppColors.textMain, 
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primary.withOpacity(0.1),
                        blurRadius: 15,
                        offset: const Offset(0, 8),
                      )
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatItem('Current KM', '${selectedCar.currentKm.toInt()} k', CupertinoIcons.speedometer),
                      Container(width: 1, height: 30, color: Colors.white24),
                      _buildStatItem('Next Service', 'Soon', CupertinoIcons.calendar),
                      Container(width: 1, height: 30, color: Colors.white24),
                      _buildStatItem('Status', 'Healthy', CupertinoIcons.checkmark_shield_fill),
                    ],
                  ),
                ),

                const SizedBox(height: 15),

                // التابات (History & Maintenance)
                TabBar(
                  controller: _tabController,
                  labelColor: AppColors.textMain,
                  unselectedLabelColor: Colors.grey,
                  indicatorColor: AppColors.primary,
                  indicatorWeight: 4,
                  indicatorSize: TabBarIndicatorSize.label,
                  labelStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 0.5),
                  tabs: const [
                    Tab(text: 'HISTORY'),
                    Tab(text: 'MAINTENANCE'),
                  ],
                ),

                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: const [
                      HistoryTab(),
                      MaintenanceTab(),
                    ],
                  ),
                ),

                // ✅ تعديل رقم 2: زر ADD ALL TO CART بتصميم Pill-shaped أنيق وصغير الحجم
                Padding(
                  padding: const EdgeInsets.only(bottom: 100, top: 10),
                  child: Center(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        // منطق الإضافة للسلة
                      },
                      icon: const Icon(Icons.add_shopping_cart_rounded, color: Colors.black, size: 20),
                      label: const Text(
                        'ADD ALL TO CART',
                        style: TextStyle(color: Colors.black, fontWeight: FontWeight.w900, letterSpacing: 0.5, fontSize: 13),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        padding: const EdgeInsets.symmetric(horizontal: 35, vertical: 12),
                        shape: const StadiumBorder(), // شكل الكبسولة الأنيق
                        elevation: 6,
                        shadowColor: AppColors.primary.withOpacity(0.4),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: AppColors.primary, size: 18),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
        ),
        Text(
          label,
          style: const TextStyle(color: Colors.grey, fontSize: 9, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}