import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:easy_localization/easy_localization.dart';

import 'firebase_options.dart';

import 'features/pages/home_page.dart';
import 'features/pages/sos_page.dart';
import 'features/pages/maintenance_page.dart';
import 'features/pages/tires_batteries.dart';
import 'features/pages/services_page.dart';
import 'features/pages/care_page.dart';
import 'features/pages/my_garage_page.dart';
import 'features/pages/profile_page.dart';

import 'core/constants/app_colors.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await EasyLocalization.ensureInitialized();

  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('en'), Locale('ar')],
      path: 'assets/translations',
      fallbackLocale: const Locale('en'),
      startLocale: const Locale('en'),
      child: const ElGarageApp(),
    ),
  );
}

class ElGarageApp extends StatefulWidget {
  const ElGarageApp({super.key});

  @override
  State<ElGarageApp> createState() => _ElGarageAppState();
}

class _ElGarageAppState extends State<ElGarageApp> {
  final GlobalKey<NavigatorState> _navKey = GlobalKey<NavigatorState>();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (_, child) {
        return MaterialApp(
          title: 'El Garage',
          debugShowCheckedModeBanner: false,
          navigatorKey: _navKey,
          
          // Localization
          localizationsDelegates: context.localizationDelegates,
          supportedLocales: context.supportedLocales,
          locale: context.locale,

          theme: ThemeData(
            useMaterial3: true,
            scaffoldBackgroundColor: AppColors.background,
            colorScheme: ColorScheme.fromSeed(
              seedColor: AppColors.primary,
              brightness: Brightness.dark,
            ),
            fontFamily: 'Tajawal',
          ),

          // Routes
          initialRoute: '/',
          routes: {
            '/': (context) => const HomePage(),
            '/sos': (context) => const SosPage(),
            '/maintenance': (context) => const MaintenancePage(),
            '/tires': (context) => const TiresBatteriesPage(),
            '/services': (context) => const ServicesPage(),
            '/care': (context) => const CarePage(),
            '/garage': (context) => const MyGaragePage(),
            '/profile': (context) => const ProfilePage(),
          },

          // Assistant Overlay
          builder: (context, child) {
            return Directionality(
              // 2. استخدام ui.TextDirection لحل التضارب
              textDirection: context.locale.languageCode == 'ar' 
                  ? ui.TextDirection.rtl 
                  : ui.TextDirection.ltr,
              child: Stack(
                children: [
                  if (child != null) child,
                ],
              ),
            );
          },
        );
      },
    );
  }
}