import 'package:automentor/features/pages/spare_parts_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:easy_localization/easy_localization.dart';
import '../../core/constants/app_colors.dart';
import '../../core/widgets/hero_section.dart'; // تأكد من استيراد الملف الجديد
import 'care_page.dart';
import 'maintenance_page.dart';
import 'services_page.dart';
import 'sos_page.dart';
import 'tires_batteries.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    // قائمة الخدمات مع مفاتيح الترجمة
    final List<Map<String, dynamic>> services = [
            {
        'title': 'services_title',
        'icon': Icons.speed,
        'page': const ServicesPage(),
        'color': Colors.teal
      },

      {'title': 'spare_parts_title',
       'icon': Icons.settings_input_component,
        'page': const SparePartsPage(),
         'color': Colors.indigo
      },
      {
        'title': 'maintenance_title',
        'icon': Icons.build_circle_outlined,
        'page': const MaintenancePage(),
        'color': Colors.blue
      },
            {
        'title': 'car_care_title',
        'icon': Icons.cleaning_services_outlined,
        'page': const CarePage(),
        'color': Colors.purple
      },
      {
        'title': 'tires_batteries',
        'icon': Icons.car_repair,
        'page': const TiresBatteriesPage(),
        'color': Colors.orange
      },

            {
        'title': 'sos_title', // مفتاح الترجمة
        'icon': Icons.warning_amber_rounded,
        'page': const SosPage(),
        'color': Colors.redAccent
      },
      {
        'title': 'my_garage',
        'icon': Icons.garage_outlined,
        'page': null, // سيتم التوجيه عبر النافيجيتور
        'color': const Color.fromARGB(255, 51, 51, 51)
      },
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. الهيرو سكشن الجديد (فيه البحث واللغة والبروفايل)
            HeroSection(
              onSearch: (query) {
                // منطق البحث هنا لاحقاً
              },
            ),
                        // 3. شبكة الخدمات
            Expanded(
              child: AnimationLimiter(
                child: GridView.builder(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 15.w,
                    mainAxisSpacing: 15.h,
                    childAspectRatio: 1.1,
                  ),
                  itemCount: services.length,
                  itemBuilder: (context, index) {
                    return AnimationConfiguration.staggeredGrid(
                      position: index,
                      duration: const Duration(milliseconds: 500),
                      columnCount: 2,
                      child: ScaleAnimation(
                        child: FadeInAnimation(
                          child: _buildGlassCard(context, services[index]),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlassCard(BuildContext context, Map<String, dynamic> item) {
    return GestureDetector(
      onTap: () {
        if (item['title'] == 'my_garage') {
          Navigator.pushNamed(context, '/garage');
        } else if (item['page'] != null) {
          Navigator.push(context, MaterialPageRoute(builder: (_) => item['page']));
        }
      },
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(24.r),
          border: Border.all(color: Colors.white10),
          boxShadow: [
            BoxShadow(color: Colors.black12, blurRadius: 10.r, offset: Offset(0, 5.h))
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(14.w),
              decoration: BoxDecoration(
                color: (item['color'] as Color).withAlpha(1),
                shape: BoxShape.circle,
              ),
              child: Icon(item['icon'], color: item['color'], size: 28.sp),
            ),
            SizedBox(height: 12.h),
            Text(
              (item['title'] as String).tr(), // ترجمة العنوان
              textAlign: TextAlign.center,
              style: TextStyle(
                color: const Color.fromARGB(255, 0, 0, 0),
                fontSize: 15.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}