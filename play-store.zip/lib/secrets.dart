class Secrets {
  static const String openAiApiKey = "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"; 
 static const elevenLabsApiKey = 'sk_fb1e40fa55f981405a5383593aaef0addb823daaf9aa3935';
  static const elevenLabsVoiceId = 'IES4nrmZdUBHByLBde0P'; // مثلاً من ElevenLabs Studio
  static const elevenLabsModelId = 'eleven_multilingual_v2'; // يدعم العربية

}


//wtliuexzvjxgabaq
//IES4nrmZdUBHByLBde0P راجل عربي لطيف