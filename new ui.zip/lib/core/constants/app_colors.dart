import 'package:flutter/material.dart';

class AppColors {
  // اللون الأساسي (البرتقالي الذهبي / Amber Gold)
  // ده اللون اللي في اللوجو حسب وصفك (مش أحمر)
  static const Color primary = Color(0xFFFFC107); // Amber/Gold
  static const Color primaryDark = Color(0xFFFFA000); // ظل أغمق
  static const Color accent = Color(0xFFFFD54F); // درجة أفتح

  // روح الجراج (Dark Theme)
  // الخلفية أسود كربوني مش أسود صريح (عشان العين)
  static const Color background = Color(0xFF121212); 
  
  // الكروت رمادي معدني داكن (Gunmetal Grey)
  static const Color surface = Color(0xFF1E1E1E); 
  static const Color surfaceLight = Color(0xFF2C2C2C); // للعناصر البارزة

  // النصوص والأيقونات
  static const Color textPrimary = Color(0xFFE0E0E0); // أبيض مائل للرمادي (مش ناصع)
  static const Color textSecondary = Color(0xFFA0A0A0); // رمادي متوسط
  static const Color iconColor = Color(0xFFBDBDBD); // فضي

  // الحالات (Functional)
  static const Color success = Color(0xFF4CAF50); // أخضر
  static const Color warning = Color(0xFFFF9800); // برتقالي
  static const Color error = Color(0xFFCF6679); // أحمر باهت للداكن

  // تدرج لوني معدني (للهيرو والخلفيات)
  static const LinearGradient darkMetalGradient = LinearGradient(
    colors: [surface, background],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  // تدرج البراند (للأزرار المهمة)
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primary, primaryDark],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // (للتوافق مع أي كود قديم)
  static const Color cardColor = surface;
  static const Color secondary = accent;
}