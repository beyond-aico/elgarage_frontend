import 'package:flutter/material.dart';
import '../core/constants/app_colors.dart';
import '../data/models/car_model.dart';

class PremiumCarCard extends StatelessWidget {
  final Car car;
  const PremiumCarCard({super.key, required this.car});

  @override
  Widget build(BuildContext context) {
    final bool hasImage = car.imageUrl != null && car.imageUrl!.isNotEmpty;

    // استخدام Material بدل Container عشان التأثيرات التفاعلية (Ripple Effect)
    return Material(
      color: Colors.transparent,
      elevation: 8,
      shadowColor: Colors.black.withOpacity(0.5),
      borderRadius: BorderRadius.circular(24),
      child: Container(
        height: 220, // ارتفاع ثابت للكارت
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          // خلفية متدرجة داكنة
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.surfaceLight, AppColors.surface],
          ),
          // حدود خفيفة (Border)
          border: Border.all(color: AppColors.surfaceLight.withOpacity(0.5), width: 1),
          // تأثير توهج خفيف (Glow) بلون البراند
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withOpacity(0.1),
              blurRadius: 20,
              offset: const Offset(0, 10),
              spreadRadius: 0,
            )
          ]
        ),
        // ClipRRect عشان الصورة تحترم الحدود الدائرية
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              // 1. خلفية الصورة (نصف الكارت)
              Positioned.fill(
                child: hasImage
                    ? Image.network(
                        car.imageUrl!,
                        fit: BoxFit.cover,
                        // إضافة تأثير تغميق على الصورة عشان الكلام يبان
                        color: Colors.black.withOpacity(0.4),
                        colorBlendMode: BlendMode.darken,
                        errorBuilder: (context, error, stackTrace) => _buildPlaceholder(),
                      )
                    : _buildPlaceholder(),
              ),

              // 2. طبقة تدرج لوني فوق الصورة (لزيادة الوضوح)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        AppColors.background.withOpacity(0.9), // تدرج للأسود تحت
                      ],
                      stops: const [0.4, 1.0],
                    ),
                  ),
                ),
              ),

              // 3. محتوى الكارت (البيانات)
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end, // المحتوى تحت
                  children: [
                    // الماركة والموديل بخط كبير
                    Text(
                      "${car.make} ${car.model}",
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.1,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    
                    const SizedBox(height: 8),
                    
                    // صف التفاصيل (سنة - لون - كيلومتر)
                    Row(
                      children: [
                        _buildDetailChip(Icons.calendar_today, "${car.year}"),
                        const SizedBox(width: 8),
                        _buildDetailChip(Icons.palette, car.color ?? "N/A"),
                        const Spacer(),
                        // عداد الكيلومتر المميز
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.9),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: AppColors.primary, width: 1),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.speed, color: Colors.white, size: 16),
                              const SizedBox(width: 6),
                              Text(
                                "${car.currentKm} KM",
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              // علامة الماركة (اختياري في المستقبل)
              Positioned(
                top: 20,
                right: 20,
                child: Icon(Icons.directions_car_filled_outlined, color: Colors.white.withOpacity(0.3), size: 32),
              )
            ],
          ),
        ),
      ),
    );
  }

  // ودجت للصورة الاحتياطية
  Widget _buildPlaceholder() {
    return Container(
      color: AppColors.surface,
      child: Center(
        child: Icon(Icons.directions_car, size: 80, color: AppColors.iconColor.withOpacity(0.2)),
      ),
    );
  }

  // ودجت لتفاصيل المعلومات الصغيرة
  Widget _buildDetailChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: AppColors.textSecondary, size: 14),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(color: AppColors.textSecondary, fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}