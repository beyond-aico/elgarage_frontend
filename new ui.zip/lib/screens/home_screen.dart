import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_colors.dart';
import '../providers/app_provider.dart';
import '../providers/auth_provider.dart';
import '../widgets/car_card.dart';
import 'profile_screen.dart'; // استيراد صفحة البروفايل

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, this.onCarSelected});
  final VoidCallback? onCarSelected;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AppProvider>(context, listen: false).fetchMyCars();
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final appProvider = Provider.of<AppProvider>(context);
    
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea( // مهمة عشان الهيرو ميتغطاش بالـ Status Bar
        child: RefreshIndicator(
          color: AppColors.primary,
          backgroundColor: AppColors.surface,
          onRefresh: () async {
            await appProvider.fetchMyCars();
          },
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              // 1. الهيرو الجديد (Garage Header)
              SliverToBoxAdapter(
                child: Container(
                  padding: const EdgeInsets.all(24.0),
                  decoration: const BoxDecoration(
                    // خلفية متدرجة معدنية
                    gradient: AppColors.darkMetalGradient,
                    borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
                  ),
                  child: Column(
                    children: [
                      // الصف العلوي: الترحيب واللوجو
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Welcome Back (شمال)
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Welcome Back,",
                                style: TextStyle(color: AppColors.textSecondary, fontSize: 16),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                authProvider.user?.name ?? "Driver",
                                style: const TextStyle(
                                  color: AppColors.textPrimary,
                                  fontSize: 28,
                                  fontWeight: FontWeight.w900, // خط سميك جداً
                                  letterSpacing: 1.1,
                                ),
                              ),
                            ],
                          ),
                          // اللوجو (يمين)
                          // تأكد إن ملف logo.png موجود في assets/images/
                          Image.asset(
                            'assets/images/logo.png',
                            height: 120, // حجم مناسب للوجو
                            // color: AppColors.primary, // ممكن تلونه لو اللوجو أسود بس
                          ),
                        ],
                      ),
                      
                      const SizedBox(height: 25),

                      // زرار البروفايل الدائري (تحت)
                      GestureDetector(
                        onTap: () {
                          // الانتقال لصفحة البروفايل
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const ProfileScreen()),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          decoration: BoxDecoration(
                            color: AppColors.surfaceLight.withValues(alpha: 0.5),
                            borderRadius: BorderRadius.circular(50),
                            border: Border.all(color: AppColors.primary.withValues(alpha: 0.3)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min, // على قد المحتوى
                            children: [
                              // صورة البروفايل (أو أيقونة)
                              const CircleAvatar(
                                radius: 18,
                                backgroundColor: AppColors.primary,
                                child: Icon(Icons.person, size: 20, color: Colors.black),
                                // ممكن هنا تحط صورة اليوزر
                              ),
                              const SizedBox(width: 12),
                              const Text(
                                "My Profile & Settings",
                                style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(width: 8),
                              const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.textSecondary),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // 2. عنوان (Your Garage)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 30, 24, 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                       const Text(
                        "YOUR GARAGE",
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),
                      // زرار إضافة سيارة
                      IconButton(
                         onPressed: () {
                           // Navigate to add car screen
                         },
                         icon: Icon(Icons.add_circle_outline, color: AppColors.primary),
                         tooltip: "Add New Car",
                      )
                    ],
                  ),
                ),
              ),

              // 3. قائمة السيارات (باستخدام PremiumCarCard اللي عملناه)
              Builder(
                builder: (context) {
                  if (appProvider.isLoadingCars) {
                    return const SliverFillRemaining(
                      child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
                    );
                  }
                  
                  if (appProvider.myCars.isEmpty) {
                    // ممكن تستخدم ودجت EmptyState هنا
                    return const SliverToBoxAdapter(child: SizedBox(height: 200, child: Center(child: Text("No cars yet", style: TextStyle(color: Colors.white)))));
                  }

                  return SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        final car = appProvider.myCars[index];
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          child: GestureDetector(
                            onTap: () async {
                              appProvider.setSelectedCar(car);
                              await appProvider.fetchDueMaintenance(carId: car.id);
                              if (widget.onCarSelected != null) {
                                widget.onCarSelected!();
                              }
                            },
                            // تأكد إنك بتستخدم PremiumCarCard اللي عملناه في الخطوة اللي فاتت
                            child: Hero(
                              tag: 'car_hero_${car.id}',
                              child: PremiumCarCard(car: car), 
                            ),
                          ),
                        );
                      },
                      childCount: appProvider.myCars.length,
                    ),
                  );
                },
              ),
              
              // مسافة في الآخر
              const SliverToBoxAdapter(child: SizedBox(height: 120)),
            ],
          ),
        ),
      ),
    );
  }
}