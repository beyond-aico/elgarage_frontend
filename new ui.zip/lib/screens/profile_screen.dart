import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_colors.dart';
import '../providers/auth_provider.dart';
import 'login_screen.dart'; // عشان الـ Logout

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final user = authProvider.user;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text("My Profile", style: TextStyle(color: AppColors.textPrimary)),
        backgroundColor: AppColors.surface,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // 1. صورة البروفايل والاسم
            Center(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: AppColors.surfaceLight,
                    child: const Icon(Icons.person, size: 50, color: AppColors.primary),
                    // هنا ممكن تضيف صورة اليوزر لو موجودة
                    // backgroundImage: user?.photoUrl != null ? NetworkImage(user!.photoUrl!) : null,
                  ),
                  const SizedBox(height: 15),
                  Text(
                    user?.name ?? "Car Owner",
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                  ),
                  Text(
                    user?.email ?? "",
                    style: const TextStyle(color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            // 2. القائمة (About Us, Policy, Logout)
            Container(
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  _buildProfileTile(icon: Icons.info_outline, title: "About Us", onTap: () {}),
                  _buildDivider(),
                  _buildProfileTile(icon: Icons.privacy_tip_outlined, title: "Privacy Policy", onTap: () {}),
                  _buildDivider(),
                  _buildProfileTile(icon: Icons.help_outline, title: "Help & Support", onTap: () {}),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // زرار تسجيل الخروج
            Container(
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
              ),
              child: _buildProfileTile(
                icon: Icons.logout,
                title: "Logout",
                textColor: AppColors.error,
                iconColor: AppColors.error,
                onTap: () {
                  authProvider.logout();
                   // الرجوع لصفحة اللوجن وحذف الـ stack
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (context) => const LoginScreen()),
                    (Route<dynamic> route) => false,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color textColor = AppColors.textPrimary,
    Color iconColor = AppColors.iconColor,
  }) {
    return ListTile(
      leading: Icon(icon, color: iconColor),
      title: Text(title, style: TextStyle(color: textColor, fontWeight: FontWeight.w600)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: AppColors.textSecondary),
      onTap: onTap,
    );
  }

  Widget _buildDivider() {
    return Divider(color: AppColors.surfaceLight.withValues(alpha: 0.5), height: 1);
  }
}