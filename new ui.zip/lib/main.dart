import 'package:elgarage/screens/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'core/constants/app_colors.dart';
import 'providers/app_provider.dart';
import 'providers/auth_provider.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const ElGarageApp());
}

class ElGarageApp extends StatelessWidget {
  const ElGarageApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
      ],
      child: MaterialApp(
        title: 'El Garage',
        debugShowCheckedModeBanner: false,
        
        // 1. إجبار الثيم الداكن (Garage Mode)
        themeMode: ThemeMode.dark,
        
        // 2. تصميم الثيم
        darkTheme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          primaryColor: AppColors.primary,
          scaffoldBackgroundColor: AppColors.background,
          
          // خطوط كايرو (لون فاتح على خلفية داكنة)
          textTheme: GoogleFonts.cairoTextTheme(ThemeData.dark().textTheme).copyWith(
            headlineLarge: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.textPrimary),
            titleLarge: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
            bodyLarge: const TextStyle(color: AppColors.textPrimary),
            bodyMedium: const TextStyle(color: AppColors.textSecondary),
          ),
          
          // نظام الألوان
          colorScheme: const ColorScheme.dark(
            primary: AppColors.primary,
            secondary: AppColors.accent,
            surface: AppColors.surface,
            background: AppColors.background,
            error: AppColors.error,
            onPrimary: Colors.black, // النصوص على الزرار البرتقالي تكون سوداء
          ),

          // تصميم الأزرار (برتقالي وأسود)
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.black, // نص أسود على خلفية برتقالي
              elevation: 4,
              shadowColor: AppColors.primary.withValues(alpha: 0.3),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
              textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
            ),
          ),
          
          // تصميم الكروت (معدني داكن)
          cardTheme: CardThemeData(
            color: AppColors.surface,
            elevation: 4,
            shadowColor: Colors.black.withValues(alpha: 0.5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: AppColors.surfaceLight.withValues(alpha: 0.3), width: 1),
            ),
          ),
          
          // تصميم الـ AppBar
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.transparent,
            elevation: 0,
            centerTitle: true,
            iconTheme: IconThemeData(color: AppColors.textPrimary),
          ),
        ),
        
        home: const LoginScreen(),
      ),
    );
  }
}