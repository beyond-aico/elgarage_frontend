import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_colors.dart';
import '../providers/app_provider.dart';

class AddCarScreen extends StatefulWidget {
  const AddCarScreen({super.key});

  @override
  State<AddCarScreen> createState() => _AddCarScreenState();
}

class _AddCarScreenState extends State<AddCarScreen> {
  final _formKey = GlobalKey<FormState>();
  
  // Lists from Backend
  List<dynamic> _brands = [];
  List<dynamic> _models = [];

  // Selections
  String? _selectedBrandId;
  String? _selectedModelId;
  
  // Controllers
  final _yearController = TextEditingController();
  final _colorController = TextEditingController();
  final _kmController = TextEditingController();

  bool _isLoadingBrands = true;
  bool _isLoadingModels = false;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    // Fetch brands immediately
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadBrands();
    });
  }

  // 1. Load Brands
  Future<void> _loadBrands() async {
    try {
      final brands = await Provider.of<AppProvider>(context, listen: false).fetchBrands();
      if (mounted) {
        setState(() {
          _brands = brands;
          _isLoadingBrands = false;
        });
      }
    } catch (e) {
      debugPrint("Error loading brands: $e");
      if (mounted) setState(() => _isLoadingBrands = false);
    }
  }

  // 2. Load Models when Brand is selected
  Future<void> _onBrandChanged(String? brandId) async {
    if (brandId == null) return;
    
    setState(() {
      _selectedBrandId = brandId;
      _selectedModelId = null; // Reset model
      _models = [];
      _isLoadingModels = true;
    });

    try {
      final models = await Provider.of<AppProvider>(context, listen: false).fetchModels(brandId);
      if (mounted) {
        setState(() {
          _models = models;
          _isLoadingModels = false;
        });
      }
    } catch (e) {
      debugPrint("Error loading models: $e");
      if (mounted) setState(() => _isLoadingModels = false);
    }
  }

  // 3. Save Car
  Future<void> _saveCar() async {
    if (!_formKey.currentState!.validate()) return;

    if (_selectedBrandId == null || _selectedModelId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select Brand and Model")),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    final carData = {
      "brandId": int.tryParse(_selectedBrandId!) ?? _selectedBrandId, // Send as int if backend expects int
      "modelId": int.tryParse(_selectedModelId!) ?? _selectedModelId, // Send as int if backend expects int
      "year": int.parse(_yearController.text),
      "color": _colorController.text,
      "mileageKm": int.parse(_kmController.text),
      "plateNumber": "No Plate", 
    };

    final success = await Provider.of<AppProvider>(context, listen: false).addNewCarv2(carData);

    if (mounted) {
      setState(() => _isSubmitting = false);
      if (success) {
        Navigator.pop(context); // Return to Home
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Car Added Successfully!"), backgroundColor: Colors.green),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to add car"), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add New Car")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // --- 1. Brand Dropdown ---
              _isLoadingBrands 
                ? const CircularProgressIndicator()
                : DropdownButtonFormField<String>(
                    decoration: _inputDecoration("Select Brand", Icons.branding_watermark),
                    value: _selectedBrandId,
                    items: _brands.map((brand) {
                      return DropdownMenuItem<String>(
                        value: brand['id'].toString(),
                        child: Text(brand['name'].toString()),
                      );
                    }).toList(),
                    onChanged: _onBrandChanged,
                    validator: (v) => v == null ? "Required" : null,
                  ),

              const SizedBox(height: 15),

              // --- 2. Model Dropdown ---
              _isLoadingModels
                ? const CircularProgressIndicator()
                : DropdownButtonFormField<String>(
                    decoration: _inputDecoration("Select Model", Icons.car_repair),
                    value: _selectedModelId,
                    items: _models.map((model) {
                      return DropdownMenuItem<String>(
                        value: model['id'].toString(),
                        child: Text(model['name'].toString()),
                      );
                    }).toList(),
                    onChanged: (val) => setState(() => _selectedModelId = val),
                    validator: (v) => v == null ? "Required" : null,
                  ),

              const SizedBox(height: 15),

              // --- 3. Year ---
              TextFormField(
                controller: _yearController,
                keyboardType: TextInputType.number,
                decoration: _inputDecoration("Year (e.g. 2020)", Icons.calendar_today),
                validator: (v) => v!.isEmpty ? "Required" : null,
              ),

              const SizedBox(height: 15),

              // --- 4. Color ---
              TextFormField(
                controller: _colorController,
                decoration: _inputDecoration("Color", Icons.color_lens),
                validator: (v) => v!.isEmpty ? "Required" : null,
              ),

              const SizedBox(height: 15),

              // --- 5. Current KM ---
              TextFormField(
                controller: _kmController,
                keyboardType: TextInputType.number,
                decoration: _inputDecoration("Current Mileage (KM)", Icons.speed),
                validator: (v) => v!.isEmpty ? "Required" : null,
              ),

              const SizedBox(height: 30),

              // --- Submit Button ---
              ElevatedButton(
                onPressed: _isSubmitting ? null : _saveCar,
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  backgroundColor: AppColors.primary,
                ),
                child: _isSubmitting 
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("Add Car", style: TextStyle(color: Colors.white, fontSize: 16)),
              )
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    );
  }
}