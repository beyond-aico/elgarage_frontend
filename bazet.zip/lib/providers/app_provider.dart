import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../data/models/car_model.dart';
import '../data/models/maintenance_item_model.dart';
import '../data/models/product_model.dart'; 
import 'auth_provider.dart';

// --- تعريفات الكلاسات المساعدة ---
class ServiceLog {
  final String id;
  final String serviceName;
  final DateTime date;
  final double cost;
  final String garageName;
  final String notes;

  var mileage;

  ServiceLog({
    required this.id,
    required this.serviceName,
    required this.date,
    required this.cost,
    required this.garageName,
    required this.notes,
  });

  get partsReplaced => null;
}

class EmergencyContact {
  final String id;
  final String name;
  final String phoneNumber;
  final String location;
  final String rating;
  final String type;

  EmergencyContact({
    required this.id,
    required this.name,
    required this.phoneNumber,
    required this.location,
    required this.rating,
    required this.type,
  });
}
// ------------------------------------

class AppProvider with ChangeNotifier {
  // 1. CARS SECTION
  List<Car> _myCars = [];
  List<MaintenanceItem> _dueMaintenance = [];
  bool _isLoadingCars = false;
  bool _isLoadingMaintenance = false;
  Car? _selectedCar;

  List<Car> get myCars => _myCars;
  List<MaintenanceItem> get dueMaintenance => _dueMaintenance;
  bool get isLoadingCars => _isLoadingCars;
  bool get isLoadingMaintenance => _isLoadingMaintenance;
  Car? get selectedCar => _selectedCar;

  void setSelectedCar(Car car) {
    _selectedCar = car;
    notifyListeners();
  }

  Future<void> fetchMyCars() async {
    _isLoadingCars = true;
    notifyListeners();
    try {
      final token = await AuthProvider.getToken();
      final response = await http.get(
        Uri.parse('http://192.168.8.15:3000/api/v1/cars'),
        headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List carsList = (data is Map && data.containsKey('data')) ? data['data'] : data;
        _myCars = carsList.map((item) => Car.fromJson(item)).toList();
      }
    } catch (e) {
      debugPrint("❌ Error fetching cars: $e");
    } finally {
      _isLoadingCars = false;
      notifyListeners();
    }
  }

  Future<void> fetchDueMaintenance({String? carId}) async {
    final targetId = carId ?? _selectedCar?.id;
    if (targetId == null) return;

    _isLoadingMaintenance = true;
    _dueMaintenance = [];
    notifyListeners();

    try {
      final token = await AuthProvider.getToken();
      final url = 'http://192.168.8.15:3000/api/v1/maintenance/$targetId/due';
      final response = await http.get(
        Uri.parse(url),
        headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List maintenanceList = (data is List) ? data : (data['data'] as List);
        _dueMaintenance = maintenanceList.map((item) => MaintenanceItem.fromJson(item)).toList();
      }
    } catch (e) {
      debugPrint("❌ Error fetching maintenance: $e");
    } finally {
      _isLoadingMaintenance = false;
      notifyListeners();
    }
  }

  // 2. ADD CAR SECTION (تم التصحيح: إضافة التوكن)
  
  Future<List<dynamic>> fetchBrands() async {
    try {
      // 🔥 التعديل هنا: إضافة التوكن
      final token = await AuthProvider.getToken(); 
      final response = await http.get(
        Uri.parse('http://192.168.8.15:3000/api/v1/cars/brands'),
        headers: {
          'Authorization': 'Bearer $token', // مهم جداً
          'Content-Type': 'application/json'
        }
      );
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return (data is Map && data.containsKey('data')) ? data['data'] : data;
      } else {
        debugPrint("Brands Error: ${response.statusCode} - ${response.body}");
      }
    } catch (e) {
      debugPrint("Error fetching brands: $e");
    }
    return [];
  }

  Future<List<dynamic>> fetchModels(String brandId) async {
    try {
      // 🔥 التعديل هنا: إضافة التوكن
      final token = await AuthProvider.getToken();
      final response = await http.get(
        Uri.parse('http://192.168.8.15:3000/api/v1/cars/models/$brandId'),
        headers: {
          'Authorization': 'Bearer $token', // مهم جداً
          'Content-Type': 'application/json'
        }
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return (data is Map && data.containsKey('data')) ? data['data'] : data;
      }
    } catch (e) {
      debugPrint("Error fetching models: $e");
    }
    return [];
  }

  Future<bool> addNewCarv2(Map<String, dynamic> carData) async {
    try {
      final token = await AuthProvider.getToken();
      final response = await http.post(
        Uri.parse('http://192.168.8.15:3000/api/v1/cars'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: json.encode(carData),
      );
      if (response.statusCode == 201 || response.statusCode == 200) {
        await fetchMyCars();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // 3. CART SECTION
  final List<ProductModel> _cartItems = [];
  List<ProductModel> get cartItems => _cartItems;
  double get cartTotal => _cartItems.fold(0, (sum, item) => sum + item.price);

  void addToCart(List<ProductModel> items) {
    _cartItems.addAll(items);
    notifyListeners();
  }

  void removeFromCart(ProductModel item) {
    _cartItems.remove(item);
    notifyListeners();
  }

  List<dynamic> get serviceCenters => [
    {'name': 'El-Garage Center', 'location': 'Maadi', 'labor_cost': 200.0},
    {'name': 'AutoFix Hub', 'location': 'Nasr City', 'labor_cost': 150.0},
  ];

  // 4. MARKETPLACE SECTION
  List<String> get categories => ['All', 'Oils', 'Filters', 'Brakes', 'Accessories'];
  
  List<ProductModel> get marketProducts => [
    ProductModel(id: '1', name: 'Shell Helix 5W40', price: 850, category: 'Oils', description: 'Synthetic Oil'),
    ProductModel(id: '2', name: 'Mann Oil Filter', price: 250, category: 'Filters', description: 'High quality filter'),
    ProductModel(id: '3', name: 'Brembo Pads', price: 1200, category: 'Brakes', description: 'Ceramic pads'),
  ];

  // 5. HISTORY SECTION
  final List<ServiceLog> _historyLogs = [];
  List<ServiceLog> get historyLogs => _historyLogs;

  void addServiceLog(dynamic logData) {
    if (logData is Map<String, dynamic>) {
        _historyLogs.add(ServiceLog(
            id: DateTime.now().toString(),
            serviceName: logData['name'] ?? 'Service',
            date: logData['date'] ?? DateTime.now(),
            cost: 0,
            garageName: 'Manual Entry',
            notes: 'Mileage: ${logData['mileage']}'
        ));
    } else if (logData is ServiceLog) {
        _historyLogs.add(logData);
    }
    notifyListeners();
  }

  // 6. EMERGENCY SECTION
  List<EmergencyContact> getEmergencyByType(String type) {
    return [
      EmergencyContact(id: '1', name: 'Winsh Masr', phoneNumber: '19111', location: 'Cairo', rating: '4.8', type: 'Winch'),
      EmergencyContact(id: '2', name: 'Total Rescue', phoneNumber: '16666', location: 'Giza', rating: '4.5', type: 'Winch'),
    ];
  }
}