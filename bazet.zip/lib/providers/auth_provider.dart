import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../data/models/auth_response_model.dart';
import '../data/services/auth_service.dart';

class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  // ignore: unused_field
  final _storage = const FlutterSecureStorage();
  
  User? _user;
  String? _token;
  bool _isLoading = false;
  String? _errorMessage;

  User? get user => _user;
  // التعديل 1: إرجاع المستخدم الفعلي
  User? get currentUser => _user; 
  
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _token != null;

  // التعديل 2: دالة ثابتة لجلب التوكن من أي مكان في التطبيق
  static Future<String?> getToken() async {
    const storage = FlutterSecureStorage();
    return await storage.read(key: 'accessToken');
  }

  // --- Login ---
  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final response = await _authService.login(email, password);
      _user = response.user;
      _token = response.accessToken;
      
      const storage = FlutterSecureStorage();
      await storage.write(key: 'accessToken', value: _token);
      
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  // --- Register ---
  Future<bool> register(String name, String email, String phone, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    print("🚀 Starting Registration...");
    try {
      final response = await _authService.register(name, email, phone, password);
      
      print("✅ Success! Token received");
      _user = response.user;
      _token = response.accessToken;

      const storage = FlutterSecureStorage();
      await storage.write(key: 'accessToken', value: _token);

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      print("❌ Error Occurred: $e");
      _isLoading = false;
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }
  
  // --- Logout ---
  void logout() async {
    _user = null;
    _token = null;
    const storage = FlutterSecureStorage();
    await storage.delete(key: 'accessToken');
    notifyListeners();
  }
}