import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_colors.dart';
import '../providers/auth_provider.dart';
import '../widgets/textured_background.dart'; // الملف الذي يحتوي على الرسام البوهيمي
import 'main_layout.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return TexturedBackground( // تطبيق الخلفية البوهيمية المستخرجة
      child: Scaffold(
        backgroundColor: Colors.transparent, // لجعل الخلفية تظهر
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(30),
            child: Consumer<AuthProvider>(
              builder: (context, provider, child) {
                return Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      const Text('ELGARAGE', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, letterSpacing: 5)),
                      const Text('TERMINAL ACCESS', style: TextStyle(letterSpacing: 2, color: AppColors.textSub)),
                      const SizedBox(height: 50),
                      
                      // حقول الإدخال بستايل صناعي
                      _buildIndustrialInput(_emailController, 'USER_EMAIL', Icons.email_outlined),
                      const SizedBox(height: 15),
                      _buildIndustrialInput(_passwordController, 'ACCESS_KEY', Icons.lock_outline, isObscure: true),
                      
                      const SizedBox(height: 30),
                      
                      SizedBox(
                        width: double.infinity,
                        height: 60,
                        child: ElevatedButton(
                          onPressed: provider.isLoading ? null : _submit,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.textMain,
                            shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero), // زوايا حادة
                          ),
                          child: provider.isLoading 
                            ? const CircularProgressIndicator(color: AppColors.primary)
                            : const Text('INITIALIZE LOGIN', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildIndustrialInput(TextEditingController controller, String label, IconData icon, {bool isObscure = false}) {
    return TextFormField(
      controller: controller,
      obscureText: isObscure,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: AppColors.textMain),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderSide: BorderSide(color: AppColors.textMain, width: 2), borderRadius: BorderRadius.zero),
      ),
    );
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final success = await Provider.of<AuthProvider>(context, listen: false).login(_emailController.text, _passwordController.text);
    if (success && mounted) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainLayout()));
    }
  }
}