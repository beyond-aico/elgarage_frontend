import 'package:elgarage/screens/cart_screen.dart';
import 'package:elgarage/screens/marketplace_screen.dart';
import 'package:elgarage/screens/more_screen.dart'; // تأكد من استيراد شاشة الإعدادات
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import '../core/constants/app_colors.dart';
import 'home_screen.dart';
import 'car_details_screen.dart';

class MainLayout extends StatefulWidget {
  const MainLayout({super.key});

  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  // رقم الصفحة الحالية
  int _currentIndex = 0;

  // دالة لتغيير التاب من الخارج (مثلاً من الهوم سكرين عند اختيار سيارة)
  void _switchToTab(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    // تعريف الصفحات الفعلية وربطها بالـ Index
    final List<Widget> _screens = [
      // 0: My Garage (Home)
      HomeScreen(onCarSelected: () => _switchToTab(1)),
      
      // 1: My Unit (Car Details)
      const CarDetailsScreen(), 
      
      // 2: Marketplace (في المنتصف)
      const MarketplaceScreen(),
      
      // 3: Logistics (Cart Screen)
      const CartScreen(),
      
      // 4: Terminal Settings (More Screen)
      const MoreScreen(),
    ];

    return Scaffold(
      extendBody: true, // مهم جداً لجعل الفوتر يبان مقصوص تحت الـ FloatingButton
      
      // استخدام IndexedStack للحفاظ على حالة الصفحات عند التنقل
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      
      // زر الماركت بليس في المنتصف (Floating Center Button) - ستايل الكود الثاني
      floatingActionButton: FloatingActionButton(
        onPressed: () => _switchToTab(2),
        backgroundColor: AppColors.primary,
        elevation: 10,
        shape: const CircleBorder(), // شكل دائري صريح
        child: const Icon(Icons.storefront, color: Colors.black, size: 28),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

      // شريط التنقل الصناعي (BottomAppBar) - ستايل الكود الثاني
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(), // التقويسة الخاصة بالزر المركزي
        notchMargin: 8,
        color: AppColors.textMain, // الأسود الأسفلتي
        child: SizedBox(
          height: 60,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // الجانب الأيسر
              _buildNavItem(0, Icons.garage_outlined, 'My Garage'),
              _buildNavItem(1, Icons.minor_crash_outlined, 'My Unit'),
              
              const SizedBox(width: 40), // مساحة فارغة لفتحة الزر في النص
              
              // الجانب الأيمن
              _buildNavItem(3, CupertinoIcons.cart_fill, 'Basket'),
              _buildNavItem(4, Icons.terminal_outlined, 'Terminal'),
            ],
          ),
        ),
      ),
    );
  }

  // ودجت بناء عناصر القائمة المخصصة - من الكود الثاني
  Widget _buildNavItem(int index, IconData icon, String label) {
    bool isActive = _currentIndex == index;
    return GestureDetector(
      onTap: () => _switchToTab(index),
      behavior: HitTestBehavior.opaque,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon, 
              color: isActive ? AppColors.primary : Colors.white54, 
              size: 24
            ),
            const SizedBox(height: 2),
            Text(
              label.toUpperCase(), // تحويل النصوص لأحرف كبيرة للستايل الصناعي
              style: TextStyle(
                color: isActive ? AppColors.primary : Colors.white54, 
                fontSize: 9,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                letterSpacing: 0.5
              ),
            ),
          ],
        ),
      ),
    );
  }
}