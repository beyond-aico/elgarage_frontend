import 'package:elgarage/data/dummy_data/dummy_data.dart';
import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';

class DriverUpdateScreen extends StatefulWidget {
  final Map<String, dynamic> user;
  const DriverUpdateScreen({super.key, required this.user});

  @override
  State<DriverUpdateScreen> createState() => _DriverUpdateScreenState();
}

class _DriverUpdateScreenState extends State<DriverUpdateScreen> {
  late Map<String, dynamic> car;
  final _odoController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // In dummy data, we assume the driver is linked to a car ID
    car = DummyDataService.getCarById(widget.user['assignedCarId']) ?? {};
    _odoController.text = car['currentOdometer'].toString();
  }

  void _submitUpdate() {
    final newVal = double.tryParse(_odoController.text);
    if (newVal != null && newVal >= car['currentOdometer']) {
      setState(() {
        car = DummyDataService.updateOdometer(car['id'], newVal);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('ODOMETER UPDATED SUCCESSFULLY'), backgroundColor: Colors.green),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid Reading: Cannot be less than current'), backgroundColor: AppColors.danger),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('DRIVER LOG'),
        backgroundColor: AppColors.textMain,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Car Info Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: AppColors.textMain, width: 2),
              ),
              child: Column(
                children: [
                  Text(car['plateNumber'] ?? 'N/A', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                  Text('${car['make']} ${car['model']}', style: const TextStyle(fontSize: 18, color: AppColors.textSub)),
                  const Divider(thickness: 2),
                  const Text('CURRENT READING', style: TextStyle(fontWeight: FontWeight.bold)),
                  Text('${car['currentOdometer']} KM', style: const TextStyle(fontSize: 24, color: AppColors.primary, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            
            const SizedBox(height: 40),

            const Text('TODAY\'S ENDING ODOMETER', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            TextField(
              controller: _odoController,
              keyboardType: TextInputType.number,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              decoration: const InputDecoration(
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderSide: BorderSide(width: 2)),
                suffixText: 'KM',
              ),
            ),

            const Spacer(),

            ElevatedButton.icon(
              onPressed: _submitUpdate,
              icon: const Icon(Icons.save_alt),
              label: const Text('SUBMIT LOG'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(20),
                shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              ),
            ),
          ],
        ),
      ),
    );
  }
}