import 'package:elgarage/data/dummy_data/dummy_data.dart';
import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../widgets/caution_tape.dart';
// import 'car_details_screen.dart'; // Reuse your existing car details screen

class FleetDashboard extends StatefulWidget {
  const FleetDashboard({super.key});

  @override
  State<FleetDashboard> createState() => _FleetDashboardState();
}

class _FleetDashboardState extends State<FleetDashboard> {
  final List<Map<String, dynamic>> cars = DummyDataService.getFleetCars();

  @override
  Widget build(BuildContext context) {
    // Calculate Stats
    final totalCars = cars.length;
    final activeAlerts = cars.where((c) => c['status'] == 'MAINTENANCE_REQUIRED').length;
    final totalDistance = cars.fold(0.0, (sum, item) => sum + (item['currentOdometer'] as double));

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('FLEET COMMAND', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
        backgroundColor: AppColors.textMain,
        foregroundColor: AppColors.warning,
        elevation: 0,
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(10),
          child: CautionTapeDecoration(height: 10),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- STATS ROW ---
            Row(
              children: [
                _buildStatCard('FLEET SIZE', '$totalCars', Icons.directions_car, Colors.white),
                const SizedBox(width: 10),
                _buildStatCard('ALERTS', '$activeAlerts', Icons.warning_amber_rounded, AppColors.warning),
              ],
            ),
            const SizedBox(height: 10),
             _buildStatCard('TOTAL MILEAGE', '${(totalDistance/1000).toStringAsFixed(1)}k KM', Icons.speed, Colors.white, fullWidth: true),

            const SizedBox(height: 25),
            
            // --- FLEET GRID ---
            const Text(
              'ACTIVE UNITS',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.textMain),
            ),
            const SizedBox(height: 10),
            
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: cars.length,
              itemBuilder: (context, index) {
                final car = cars[index];
                final isAlert = car['status'] == 'MAINTENANCE_REQUIRED';
                
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  elevation: 4,
                  shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero), // Industrial sharp corners
                  child: Container(
                    decoration: BoxDecoration(
                       border: Border(left: BorderSide(color: isAlert ? AppColors.danger : AppColors.primary, width: 6)),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(16),
                      title: Text('${car['make']} ${car['model']}', 
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4),
                          Text('Plate: ${car['plateNumber']} | ID: ${car['id']}'),
                          Text('Odo: ${car['currentOdometer']} km', style: const TextStyle(color: AppColors.textMain, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      trailing: isAlert 
                        ? const Icon(Icons.build_circle, color: AppColors.danger, size: 30)
                        : const Icon(Icons.check_circle, color: Colors.green, size: 30),
                      onTap: () {
                         // TODO: Navigate to existing Car Details Screen passing this dummy data
                         // Navigator.push(context, MaterialPageRoute(builder: (_) => CarDetailsScreen(carData: car)));
                      },
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color bg, {bool fullWidth = false}) {
    return Expanded(
      flex: fullWidth ? 0 : 1,
      child: Container(
        width: fullWidth ? double.infinity : null,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bg,
          border: Border.all(color: AppColors.textMain, width: 2),
          boxShadow: const [BoxShadow(color: Colors.black12, offset: Offset(4, 4))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(icon, size: 28, color: AppColors.textMain),
                if(bg == AppColors.warning) const Icon(Icons.priority_high, size: 16),
              ],
            ),
            const SizedBox(height: 10),
            Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textSub)),
          ],
        ),
      ),
    );
  }
}