import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../providers/app_provider.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/textured_background.dart';
import 'add_car_screen.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback? onCarSelected;

  const HomeScreen({super.key, this.onCarSelected});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  
  @override
  void initState() {
    super.initState();
    // جلب البيانات عند فتح الشاشة لأول مرة
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AppProvider>(context, listen: false).fetchMyCars();
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final appProvider = Provider.of<AppProvider>(context);

    return TexturedBackground(
      child: SafeArea(
        child: Column(
          children: [
            // --- 1. THE CURVED HERO SECTION (Header) ---
            Stack(
              children: [
                // الخلفية المقوسة (الأسود الأسفلتي)
                ClipPath(
                  clipper: HeroClipper(),
                  child: Container(
                    height: 280,
                    width: double.infinity,
                    color: AppColors.textMain, 
                  ),
                ),
                
                // المحتوى داخل الهيرو
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // اليسار: الترحيب باليوزر الحقيقي من الـ AuthProvider
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Welcome back,', style: TextStyle(color: Colors.white70, fontSize: 14)),
                              Text(
                                authProvider.user?.name ?? 'Operator', 
                                style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900),
                              ),
                              const SizedBox(height: 8),
                              // عرض النقاط أو الـ Fleet Stats
                              Row(
                                children: [
                                  const Icon(Icons.stars, color: AppColors.primary, size: 16),
                                  const SizedBox(width: 5),
                                  Text(
                                    '${appProvider.myCars.length} Cars in Garage', 
                                    style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold, fontSize: 12),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          
                          // اليمين: الأيقونات التفاعلية
                          const Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Icon(Icons.garage_rounded, color: Colors.white, size: 40),
                              SizedBox(height: 15),
                              Icon(Icons.shopping_bag_outlined, color: Colors.white, size: 24),
                            ],
                          ),
                        ],
                      ),
                      
                      const SizedBox(height: 35),
                      
                      // زر إضافة سيارة - التصميم الصناعي
                      ElevatedButton.icon(
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const AddCarScreen()));
                        },
                        icon: const Icon(Icons.add_circle_outline, size: 20),
                        label: const Text('ADD NEW CAR', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            // --- 2. CARS LIST (Consumer لضمان تحديث القائمة) ---
            Expanded(
              child: Consumer<AppProvider>(
                builder: (context, provider, child) {
                  if (provider.isLoadingCars) {
                    return const Center(child: CircularProgressIndicator(color: AppColors.primary));
                  }

                  if (provider.myCars.isEmpty) {
                    return _buildEmptyState();
                  }

                  return RefreshIndicator(
                    onRefresh: () => provider.fetchMyCars(),
                    color: AppColors.primary,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      physics: const BouncingScrollPhysics(),
                      itemCount: provider.myCars.length,
                      itemBuilder: (context, index) {
                        final car = provider.myCars[index];
                        return _buildIndustrialCarCard(context, car, provider);
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ودجت كارت السيارة بالتصميم المطور (Watermark & Image)
  Widget _buildIndustrialCarCard(BuildContext context, dynamic car, AppProvider provider) {
    return GestureDetector(
      onTap: () async {
        // 1. تحديد السيارة المختارة في البروفايدر
        provider.setSelectedCar(car);
        // 2. جلب بيانات الصيانة الخاصة بها من الـ API
        await provider.fetchDueMaintenance(carId: car.id);
        // 3. الانتقال لتاب التفاصيل (My Car)
        if (widget.onCarSelected != null) widget.onCarSelected!();
      },
      child: Container(
        height: 170,
        margin: const EdgeInsets.only(bottom: 20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 15, offset: const Offset(0, 8))
          ],
        ),
        child: Stack(
          children: [
            // العلامة المائية (Brand Watermark)
            Positioned(
              right: 15, 
              bottom: -5, 
              child: Text(
                car.make.toString().toUpperCase(), 
                style: TextStyle(fontSize: 55, fontWeight: FontWeight.w900, color: Colors.black.withOpacity(0.04)),
              ),
            ),
            
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${car.make} ${car.model}', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(car.licensePlate ?? 'No Plate', style: const TextStyle(color: AppColors.textSub, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  Row(
                    children: [
                      const Icon(Icons.check_circle, color: AppColors.success, size: 16),
                      const SizedBox(width: 6),
                      Text(
                        'System Ready • ${car.year}', 
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // صورة السيارة (تحميل من الشبكة أو Assets)
            Positioned(
              right: -15, 
              bottom: 10, 
              child: car.imageUrl != null && car.imageUrl!.isNotEmpty
                  ? Image.network(car.imageUrl!, height: 110, errorBuilder: (c, e, s) => _buildDefaultCarIcon())
                  : _buildDefaultCarIcon(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDefaultCarIcon() {
    return const Padding(
      padding: EdgeInsets.only(right: 30, bottom: 20),
      child: Icon(Icons.directions_car_filled, size: 90, color: Colors.black12),
    );
  }

  Widget _buildEmptyState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(CupertinoIcons.car_detailed, size: 70, color: Colors.black12),
          SizedBox(height: 15),
          Text("Garage is empty", style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

// الرسام المسؤول عن تقويسة الهيرو (Custom Clipper)
class HeroClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, size.height - 60);
    path.quadraticBezierTo(size.width / 2, size.height, size.width, size.height - 60);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }
  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}