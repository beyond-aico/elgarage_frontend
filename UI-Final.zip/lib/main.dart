import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart'; // منطق النسخة 1
import 'core/constants/app_colors.dart';
import 'providers/app_provider.dart';
import 'providers/auth_provider.dart'; // منطق النسخة 1
import 'screens/login_screen.dart'; // المسار حسب شجرة الملفات الحالية

void main() async {
  // 1. ضمان تهيئة الـ Widgets (من النسخة 1 لضمان استقرار الباك إند)
  WidgetsFlutterBinding.ensureInitialized();
  
  // 2. تشغيل فايربيز (ضروري لعمل الـ Auth والبيانات)
  await Firebase.initializeApp();

  runApp(const AutoMentorApp()); // المسمى الجديد من النسخة 2
}

class AutoMentorApp extends StatelessWidget {
  const AutoMentorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // الحفاظ على كافة الـ Providers لضمان عمل الباك إند
        ChangeNotifierProvider(create: (_) => AppProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
      ],
      child: MaterialApp(
        title: 'ElGarage Fleet', // المسمى الجديد
        debugShowCheckedModeBanner: false,
        
        theme: ThemeData(
          // --- الهوية البصرية المحدثة (Industrial Identity) ---
          primaryColor: AppColors.primary,
          scaffoldBackgroundColor: AppColors.background,
          
          // استخدام الخط الصناعي Roboto بدلاً من Cairo
          fontFamily: 'Roboto', 
          
          colorScheme: const ColorScheme.light(
            primary: AppColors.primary,
            secondary: AppColors.warning,
            surface: AppColors.cardColor, // تم ربطها بـ cardColor لضمان التوافق
          ),
          
          // ستايل الأزرار الصناعي الثقيل (Industrial Button Style)
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              elevation: 4,
              shadowColor: Colors.black,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12), // حواف متوافقة مع الـ UI الجديد
              ),
            ),
          ),
          
          useMaterial3: true,
        ),
        
        // نقطة الدخول (Login Screen)
        home: const LoginScreen(),
      ),
    );
  }
}